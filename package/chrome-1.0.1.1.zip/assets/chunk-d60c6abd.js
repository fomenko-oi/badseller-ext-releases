import{b as l,A as p,U as V,a as Q,c as Nt,d as j,C as Te,g as $t,D as ot,B as Un,S as M,e as Fn,f as h,h as jn,i as xn,j as B,k as it,P as Hn,F as Kn}from"./chunk-9d8da9ff.js";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mt=function(e){const t=[];let n=0;for(let r=0;r<e.length;r++){let o=e.charCodeAt(r);o<128?t[n++]=o:o<2048?(t[n++]=o>>6|192,t[n++]=o&63|128):(o&64512)===55296&&r+1<e.length&&(e.charCodeAt(r+1)&64512)===56320?(o=65536+((o&1023)<<10)+(e.charCodeAt(++r)&1023),t[n++]=o>>18|240,t[n++]=o>>12&63|128,t[n++]=o>>6&63|128,t[n++]=o&63|128):(t[n++]=o>>12|224,t[n++]=o>>6&63|128,t[n++]=o&63|128)}return t},Vn=function(e){const t=[];let n=0,r=0;for(;n<e.length;){const o=e[n++];if(o<128)t[r++]=String.fromCharCode(o);else if(o>191&&o<224){const i=e[n++];t[r++]=String.fromCharCode((o&31)<<6|i&63)}else if(o>239&&o<365){const i=e[n++],s=e[n++],a=e[n++],c=((o&7)<<18|(i&63)<<12|(s&63)<<6|a&63)-65536;t[r++]=String.fromCharCode(55296+(c>>10)),t[r++]=String.fromCharCode(56320+(c&1023))}else{const i=e[n++],s=e[n++];t[r++]=String.fromCharCode((o&15)<<12|(i&63)<<6|s&63)}}return t.join("")},Bt={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(e,t){if(!Array.isArray(e))throw Error("encodeByteArray takes an array as a parameter");this.init_();const n=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let o=0;o<e.length;o+=3){const i=e[o],s=o+1<e.length,a=s?e[o+1]:0,c=o+2<e.length,d=c?e[o+2]:0,u=i>>2,K=(i&3)<<4|a>>4;let Y=(a&15)<<2|d>>6,X=d&63;c||(X=64,s||(Y=64)),r.push(n[u],n[K],n[Y],n[X])}return r.join("")},encodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(e):this.encodeByteArray(Mt(e),t)},decodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(e):Vn(this.decodeStringToByteArray(e,t))},decodeStringToByteArray(e,t){this.init_();const n=t?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let o=0;o<e.length;){const i=n[e.charAt(o++)],a=o<e.length?n[e.charAt(o)]:0;++o;const d=o<e.length?n[e.charAt(o)]:64;++o;const K=o<e.length?n[e.charAt(o)]:64;if(++o,i==null||a==null||d==null||K==null)throw new Wn;const Y=i<<2|a>>4;if(r.push(Y),d!==64){const X=a<<4&240|d>>2;if(r.push(X),K!==64){const Ln=d<<6&192|K;r.push(Ln)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let e=0;e<this.ENCODED_VALS.length;e++)this.byteToCharMap_[e]=this.ENCODED_VALS.charAt(e),this.charToByteMap_[this.byteToCharMap_[e]]=e,this.byteToCharMapWebSafe_[e]=this.ENCODED_VALS_WEBSAFE.charAt(e),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]]=e,e>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)]=e,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)]=e)}}};class Wn extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const qn=function(e){const t=Mt(e);return Bt.encodeByteArray(t,!0)},Pt=function(e){return qn(e).replace(/\./g,"")},Gn=function(e){try{return Bt.decodeString(e,!0)}catch(t){console.error("base64Decode failed: ",t)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zn(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Jn=()=>zn().__FIREBASE_DEFAULTS__,Yn=()=>{if(typeof process>"u"||typeof process.env>"u")return;const e={}.__FIREBASE_DEFAULTS__;if(e)return JSON.parse(e)},Xn=()=>{if(typeof document>"u")return;let e;try{e=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const t=e&&Gn(e[1]);return t&&JSON.parse(t)},Qn=()=>{try{return Jn()||Yn()||Xn()}catch(e){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);return}},Rt=()=>{var e;return(e=Qn())===null||e===void 0?void 0:e.config};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zn{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((t,n)=>{this.resolve=t,this.reject=n})}wrapCallback(t){return(n,r)=>{n?this.reject(n):this.resolve(r),typeof t=="function"&&(this.promise.catch(()=>{}),t.length===1?t(n):t(n,r))}}}function Lt(){try{return typeof indexedDB=="object"}catch{return!1}}function Ut(){return new Promise((e,t)=>{try{let n=!0;const r="validate-browser-context-for-indexeddb-analytics-module",o=self.indexedDB.open(r);o.onsuccess=()=>{o.result.close(),n||self.indexedDB.deleteDatabase(r),e(!0)},o.onupgradeneeded=()=>{n=!1},o.onerror=()=>{var i;t(((i=o.error)===null||i===void 0?void 0:i.message)||"")}}catch(n){t(n)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const er="FirebaseError";class H extends Error{constructor(t,n,r){super(n),this.code=t,this.customData=r,this.name=er,Object.setPrototypeOf(this,H.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,G.prototype.create)}}class G{constructor(t,n,r){this.service=t,this.serviceName=n,this.errors=r}create(t,...n){const r=n[0]||{},o=`${this.service}/${t}`,i=this.errors[t],s=i?tr(i,r):"Error",a=`${this.serviceName}: ${s} (${o}).`;return new H(o,a,r)}}function tr(e,t){return e.replace(nr,(n,r)=>{const o=t[r];return o!=null?String(o):`<${r}?>`})}const nr=/\{\$([^}]+)}/g;function ve(e,t){if(e===t)return!0;const n=Object.keys(e),r=Object.keys(t);for(const o of n){if(!r.includes(o))return!1;const i=e[o],s=t[o];if(st(i)&&st(s)){if(!ve(i,s))return!1}else if(i!==s)return!1}for(const o of r)if(!n.includes(o))return!1;return!0}function st(e){return e!==null&&typeof e=="object"}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ft(e){return e&&e._delegate?e._delegate:e}class _{constructor(t,n,r){this.name=t,this.instanceFactory=n,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(t){return this.instantiationMode=t,this}setMultipleInstances(t){return this.multipleInstances=t,this}setServiceProps(t){return this.serviceProps=t,this}setInstanceCreatedCallback(t){return this.onInstanceCreated=t,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const N="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rr{constructor(t,n){this.name=t,this.container=n,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(t){const n=this.normalizeInstanceIdentifier(t);if(!this.instancesDeferred.has(n)){const r=new Zn;if(this.instancesDeferred.set(n,r),this.isInitialized(n)||this.shouldAutoInitialize())try{const o=this.getOrInitializeService({instanceIdentifier:n});o&&r.resolve(o)}catch{}}return this.instancesDeferred.get(n).promise}getImmediate(t){var n;const r=this.normalizeInstanceIdentifier(t==null?void 0:t.identifier),o=(n=t==null?void 0:t.optional)!==null&&n!==void 0?n:!1;if(this.isInitialized(r)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:r})}catch(i){if(o)return null;throw i}else{if(o)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(t){if(t.name!==this.name)throw Error(`Mismatching Component ${t.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=t,!!this.shouldAutoInitialize()){if(ir(t))try{this.getOrInitializeService({instanceIdentifier:N})}catch{}for(const[n,r]of this.instancesDeferred.entries()){const o=this.normalizeInstanceIdentifier(n);try{const i=this.getOrInitializeService({instanceIdentifier:o});r.resolve(i)}catch{}}}}clearInstance(t=N){this.instancesDeferred.delete(t),this.instancesOptions.delete(t),this.instances.delete(t)}async delete(){const t=Array.from(this.instances.values());await Promise.all([...t.filter(n=>"INTERNAL"in n).map(n=>n.INTERNAL.delete()),...t.filter(n=>"_delete"in n).map(n=>n._delete())])}isComponentSet(){return this.component!=null}isInitialized(t=N){return this.instances.has(t)}getOptions(t=N){return this.instancesOptions.get(t)||{}}initialize(t={}){const{options:n={}}=t,r=this.normalizeInstanceIdentifier(t.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const o=this.getOrInitializeService({instanceIdentifier:r,options:n});for(const[i,s]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(i);r===a&&s.resolve(o)}return o}onInit(t,n){var r;const o=this.normalizeInstanceIdentifier(n),i=(r=this.onInitCallbacks.get(o))!==null&&r!==void 0?r:new Set;i.add(t),this.onInitCallbacks.set(o,i);const s=this.instances.get(o);return s&&t(s,o),()=>{i.delete(t)}}invokeOnInitCallbacks(t,n){const r=this.onInitCallbacks.get(n);if(r)for(const o of r)try{o(t,n)}catch{}}getOrInitializeService({instanceIdentifier:t,options:n={}}){let r=this.instances.get(t);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:or(t),options:n}),this.instances.set(t,r),this.instancesOptions.set(t,n),this.invokeOnInitCallbacks(r,t),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,t,r)}catch{}return r||null}normalizeInstanceIdentifier(t=N){return this.component?this.component.multipleInstances?t:N:t}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function or(e){return e===N?void 0:e}function ir(e){return e.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sr{constructor(t){this.name=t,this.providers=new Map}addComponent(t){const n=this.getProvider(t.name);if(n.isComponentSet())throw new Error(`Component ${t.name} has already been registered with ${this.name}`);n.setComponent(t)}addOrOverwriteComponent(t){this.getProvider(t.name).isComponentSet()&&this.providers.delete(t.name),this.addComponent(t)}getProvider(t){if(this.providers.has(t))return this.providers.get(t);const n=new rr(t,this);return this.providers.set(t,n),n}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var f;(function(e){e[e.DEBUG=0]="DEBUG",e[e.VERBOSE=1]="VERBOSE",e[e.INFO=2]="INFO",e[e.WARN=3]="WARN",e[e.ERROR=4]="ERROR",e[e.SILENT=5]="SILENT"})(f||(f={}));const ar={debug:f.DEBUG,verbose:f.VERBOSE,info:f.INFO,warn:f.WARN,error:f.ERROR,silent:f.SILENT},cr=f.INFO,ur={[f.DEBUG]:"log",[f.VERBOSE]:"log",[f.INFO]:"info",[f.WARN]:"warn",[f.ERROR]:"error"},dr=(e,t,...n)=>{if(t<e.logLevel)return;const r=new Date().toISOString(),o=ur[t];if(o)console[o](`[${r}]  ${e.name}:`,...n);else throw new Error(`Attempted to log a message with an invalid logType (value: ${t})`)};let lr=class{constructor(t){this.name=t,this._logLevel=cr,this._logHandler=dr,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(t){if(!(t in f))throw new TypeError(`Invalid value "${t}" assigned to \`logLevel\``);this._logLevel=t}setLogLevel(t){this._logLevel=typeof t=="string"?ar[t]:t}get logHandler(){return this._logHandler}set logHandler(t){if(typeof t!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=t}get userLogHandler(){return this._userLogHandler}set userLogHandler(t){this._userLogHandler=t}debug(...t){this._userLogHandler&&this._userLogHandler(this,f.DEBUG,...t),this._logHandler(this,f.DEBUG,...t)}log(...t){this._userLogHandler&&this._userLogHandler(this,f.VERBOSE,...t),this._logHandler(this,f.VERBOSE,...t)}info(...t){this._userLogHandler&&this._userLogHandler(this,f.INFO,...t),this._logHandler(this,f.INFO,...t)}warn(...t){this._userLogHandler&&this._userLogHandler(this,f.WARN,...t),this._logHandler(this,f.WARN,...t)}error(...t){this._userLogHandler&&this._userLogHandler(this,f.ERROR,...t),this._logHandler(this,f.ERROR,...t)}};const fr=(e,t)=>t.some(n=>e instanceof n);let at,ct;function hr(){return at||(at=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function pr(){return ct||(ct=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const jt=new WeakMap,Ae=new WeakMap,xt=new WeakMap,se=new WeakMap,Ue=new WeakMap;function gr(e){const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("success",i),e.removeEventListener("error",s)},i=()=>{n(v(e.result)),o()},s=()=>{r(e.error),o()};e.addEventListener("success",i),e.addEventListener("error",s)});return t.then(n=>{n instanceof IDBCursor&&jt.set(n,e)}).catch(()=>{}),Ue.set(t,e),t}function br(e){if(Ae.has(e))return;const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("complete",i),e.removeEventListener("error",s),e.removeEventListener("abort",s)},i=()=>{n(),o()},s=()=>{r(e.error||new DOMException("AbortError","AbortError")),o()};e.addEventListener("complete",i),e.addEventListener("error",s),e.addEventListener("abort",s)});Ae.set(e,t)}let De={get(e,t,n){if(e instanceof IDBTransaction){if(t==="done")return Ae.get(e);if(t==="objectStoreNames")return e.objectStoreNames||xt.get(e);if(t==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return v(e[t])},set(e,t,n){return e[t]=n,!0},has(e,t){return e instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in e}};function mr(e){De=e(De)}function wr(e){return e===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(t,...n){const r=e.call(ae(this),t,...n);return xt.set(r,t.sort?t.sort():[t]),v(r)}:pr().includes(e)?function(...t){return e.apply(ae(this),t),v(jt.get(this))}:function(...t){return v(e.apply(ae(this),t))}}function yr(e){return typeof e=="function"?wr(e):(e instanceof IDBTransaction&&br(e),fr(e,hr())?new Proxy(e,De):e)}function v(e){if(e instanceof IDBRequest)return gr(e);if(se.has(e))return se.get(e);const t=yr(e);return t!==e&&(se.set(e,t),Ue.set(t,e)),t}const ae=e=>Ue.get(e);function Sr(e,t,{blocked:n,upgrade:r,blocking:o,terminated:i}={}){const s=indexedDB.open(e,t),a=v(s);return r&&s.addEventListener("upgradeneeded",c=>{r(v(s.result),c.oldVersion,c.newVersion,v(s.transaction),c)}),n&&s.addEventListener("blocked",c=>n(c.oldVersion,c.newVersion,c)),a.then(c=>{i&&c.addEventListener("close",()=>i()),o&&c.addEventListener("versionchange",d=>o(d.oldVersion,d.newVersion,d))}).catch(()=>{}),a}const Er=["get","getKey","getAll","getAllKeys","count"],_r=["put","add","delete","clear"],ce=new Map;function ut(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&typeof t=="string"))return;if(ce.get(t))return ce.get(t);const n=t.replace(/FromIndex$/,""),r=t!==n,o=_r.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(o||Er.includes(n)))return;const i=async function(s,...a){const c=this.transaction(s,o?"readwrite":"readonly");let d=c.store;return r&&(d=d.index(a.shift())),(await Promise.all([d[n](...a),o&&c.done]))[0]};return ce.set(t,i),i}mr(e=>({...e,get:(t,n,r)=>ut(t,n)||e.get(t,n,r),has:(t,n)=>!!ut(t,n)||e.has(t,n)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ir{constructor(t){this.container=t}getPlatformInfoString(){return this.container.getProviders().map(n=>{if(Tr(n)){const r=n.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(n=>n).join(" ")}}function Tr(e){const t=e.getComponent();return(t==null?void 0:t.type)==="VERSION"}const ke="@firebase/app",dt="0.9.13";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const P=new lr("@firebase/app"),vr="@firebase/app-compat",Ar="@firebase/analytics-compat",Dr="@firebase/analytics",kr="@firebase/app-check-compat",Cr="@firebase/app-check",Or="@firebase/auth",Nr="@firebase/auth-compat",$r="@firebase/database",Mr="@firebase/database-compat",Br="@firebase/functions",Pr="@firebase/functions-compat",Rr="@firebase/installations",Lr="@firebase/installations-compat",Ur="@firebase/messaging",Fr="@firebase/messaging-compat",jr="@firebase/performance",xr="@firebase/performance-compat",Hr="@firebase/remote-config",Kr="@firebase/remote-config-compat",Vr="@firebase/storage",Wr="@firebase/storage-compat",qr="@firebase/firestore",Gr="@firebase/firestore-compat",zr="firebase";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ce="[DEFAULT]",Jr={[ke]:"fire-core",[vr]:"fire-core-compat",[Dr]:"fire-analytics",[Ar]:"fire-analytics-compat",[Cr]:"fire-app-check",[kr]:"fire-app-check-compat",[Or]:"fire-auth",[Nr]:"fire-auth-compat",[$r]:"fire-rtdb",[Mr]:"fire-rtdb-compat",[Br]:"fire-fn",[Pr]:"fire-fn-compat",[Rr]:"fire-iid",[Lr]:"fire-iid-compat",[Ur]:"fire-fcm",[Fr]:"fire-fcm-compat",[jr]:"fire-perf",[xr]:"fire-perf-compat",[Hr]:"fire-rc",[Kr]:"fire-rc-compat",[Vr]:"fire-gcs",[Wr]:"fire-gcs-compat",[qr]:"fire-fst",[Gr]:"fire-fst-compat","fire-js":"fire-js",[zr]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Z=new Map,Oe=new Map;function Yr(e,t){try{e.container.addComponent(t)}catch(n){P.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`,n)}}function C(e){const t=e.name;if(Oe.has(t))return P.debug(`There were multiple attempts to register component ${t}.`),!1;Oe.set(t,e);for(const n of Z.values())Yr(n,e);return!0}function Fe(e,t){const n=e.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),e.container.getProvider(t)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xr={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}."},A=new G("app","Firebase",Xr);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qr{constructor(t,n,r){this._isDeleted=!1,this._options=Object.assign({},t),this._config=Object.assign({},n),this._name=n.name,this._automaticDataCollectionEnabled=n.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new _("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(t){this.checkDestroyed(),this._automaticDataCollectionEnabled=t}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(t){this._isDeleted=t}checkDestroyed(){if(this.isDeleted)throw A.create("app-deleted",{appName:this._name})}}function Ht(e,t={}){let n=e;typeof t!="object"&&(t={name:t});const r=Object.assign({name:Ce,automaticDataCollectionEnabled:!1},t),o=r.name;if(typeof o!="string"||!o)throw A.create("bad-app-name",{appName:String(o)});if(n||(n=Rt()),!n)throw A.create("no-options");const i=Z.get(o);if(i){if(ve(n,i.options)&&ve(r,i.config))return i;throw A.create("duplicate-app",{appName:o})}const s=new sr(o);for(const c of Oe.values())s.addComponent(c);const a=new Qr(n,r,s);return Z.set(o,a),a}function Zr(e=Ce){const t=Z.get(e);if(!t&&e===Ce&&Rt())return Ht();if(!t)throw A.create("no-app",{appName:e});return t}function D(e,t,n){var r;let o=(r=Jr[e])!==null&&r!==void 0?r:e;n&&(o+=`-${n}`);const i=o.match(/\s|\//),s=t.match(/\s|\//);if(i||s){const a=[`Unable to register library "${o}" with version "${t}":`];i&&a.push(`library name "${o}" contains illegal characters (whitespace or "/")`),i&&s&&a.push("and"),s&&a.push(`version name "${t}" contains illegal characters (whitespace or "/")`),P.warn(a.join(" "));return}C(new _(`${o}-version`,()=>({library:o,version:t}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const eo="firebase-heartbeat-database",to=1,W="firebase-heartbeat-store";let ue=null;function Kt(){return ue||(ue=Sr(eo,to,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(W)}}}).catch(e=>{throw A.create("idb-open",{originalErrorMessage:e.message})})),ue}async function no(e){try{return await(await Kt()).transaction(W).objectStore(W).get(Vt(e))}catch(t){if(t instanceof H)P.warn(t.message);else{const n=A.create("idb-get",{originalErrorMessage:t==null?void 0:t.message});P.warn(n.message)}}}async function lt(e,t){try{const r=(await Kt()).transaction(W,"readwrite");await r.objectStore(W).put(t,Vt(e)),await r.done}catch(n){if(n instanceof H)P.warn(n.message);else{const r=A.create("idb-set",{originalErrorMessage:n==null?void 0:n.message});P.warn(r.message)}}}function Vt(e){return`${e.name}!${e.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ro=1024,oo=30*24*60*60*1e3;class io{constructor(t){this.container=t,this._heartbeatsCache=null;const n=this.container.getProvider("app").getImmediate();this._storage=new ao(n),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){const n=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),r=ft();if(this._heartbeatsCache===null&&(this._heartbeatsCache=await this._heartbeatsCachePromise),!(this._heartbeatsCache.lastSentHeartbeatDate===r||this._heartbeatsCache.heartbeats.some(o=>o.date===r)))return this._heartbeatsCache.heartbeats.push({date:r,agent:n}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(o=>{const i=new Date(o.date).valueOf();return Date.now()-i<=oo}),this._storage.overwrite(this._heartbeatsCache)}async getHeartbeatsHeader(){if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,this._heartbeatsCache===null||this._heartbeatsCache.heartbeats.length===0)return"";const t=ft(),{heartbeatsToSend:n,unsentEntries:r}=so(this._heartbeatsCache.heartbeats),o=Pt(JSON.stringify({version:2,heartbeats:n}));return this._heartbeatsCache.lastSentHeartbeatDate=t,r.length>0?(this._heartbeatsCache.heartbeats=r,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),o}}function ft(){return new Date().toISOString().substring(0,10)}function so(e,t=ro){const n=[];let r=e.slice();for(const o of e){const i=n.find(s=>s.agent===o.agent);if(i){if(i.dates.push(o.date),ht(n)>t){i.dates.pop();break}}else if(n.push({agent:o.agent,dates:[o.date]}),ht(n)>t){n.pop();break}r=r.slice(1)}return{heartbeatsToSend:n,unsentEntries:r}}class ao{constructor(t){this.app=t,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Lt()?Ut().then(()=>!0).catch(()=>!1):!1}async read(){return await this._canUseIndexedDBPromise?await no(this.app)||{heartbeats:[]}:{heartbeats:[]}}async overwrite(t){var n;if(await this._canUseIndexedDBPromise){const o=await this.read();return lt(this.app,{lastSentHeartbeatDate:(n=t.lastSentHeartbeatDate)!==null&&n!==void 0?n:o.lastSentHeartbeatDate,heartbeats:t.heartbeats})}else return}async add(t){var n;if(await this._canUseIndexedDBPromise){const o=await this.read();return lt(this.app,{lastSentHeartbeatDate:(n=t.lastSentHeartbeatDate)!==null&&n!==void 0?n:o.lastSentHeartbeatDate,heartbeats:[...o.heartbeats,...t.heartbeats]})}else return}}function ht(e){return Pt(JSON.stringify({version:2,heartbeats:e})).length}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function co(e){C(new _("platform-logger",t=>new Ir(t),"PRIVATE")),C(new _("heartbeat",t=>new io(t),"PRIVATE")),D(ke,dt,e),D(ke,dt,"esm2017"),D("fire-js","")}co("");var uo="firebase",lo="9.23.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */D(uo,lo,"app");const fo=(e,t)=>t.some(n=>e instanceof n);let pt,gt;function ho(){return pt||(pt=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function po(){return gt||(gt=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Wt=new WeakMap,Ne=new WeakMap,qt=new WeakMap,de=new WeakMap,je=new WeakMap;function go(e){const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("success",i),e.removeEventListener("error",s)},i=()=>{n(k(e.result)),o()},s=()=>{r(e.error),o()};e.addEventListener("success",i),e.addEventListener("error",s)});return t.then(n=>{n instanceof IDBCursor&&Wt.set(n,e)}).catch(()=>{}),je.set(t,e),t}function bo(e){if(Ne.has(e))return;const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("complete",i),e.removeEventListener("error",s),e.removeEventListener("abort",s)},i=()=>{n(),o()},s=()=>{r(e.error||new DOMException("AbortError","AbortError")),o()};e.addEventListener("complete",i),e.addEventListener("error",s),e.addEventListener("abort",s)});Ne.set(e,t)}let $e={get(e,t,n){if(e instanceof IDBTransaction){if(t==="done")return Ne.get(e);if(t==="objectStoreNames")return e.objectStoreNames||qt.get(e);if(t==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return k(e[t])},set(e,t,n){return e[t]=n,!0},has(e,t){return e instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in e}};function mo(e){$e=e($e)}function wo(e){return e===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(t,...n){const r=e.call(le(this),t,...n);return qt.set(r,t.sort?t.sort():[t]),k(r)}:po().includes(e)?function(...t){return e.apply(le(this),t),k(Wt.get(this))}:function(...t){return k(e.apply(le(this),t))}}function yo(e){return typeof e=="function"?wo(e):(e instanceof IDBTransaction&&bo(e),fo(e,ho())?new Proxy(e,$e):e)}function k(e){if(e instanceof IDBRequest)return go(e);if(de.has(e))return de.get(e);const t=yo(e);return t!==e&&(de.set(e,t),je.set(t,e)),t}const le=e=>je.get(e);function So(e,t,{blocked:n,upgrade:r,blocking:o,terminated:i}={}){const s=indexedDB.open(e,t),a=k(s);return r&&s.addEventListener("upgradeneeded",c=>{r(k(s.result),c.oldVersion,c.newVersion,k(s.transaction))}),n&&s.addEventListener("blocked",()=>n()),a.then(c=>{i&&c.addEventListener("close",()=>i()),o&&c.addEventListener("versionchange",()=>o())}).catch(()=>{}),a}const Eo=["get","getKey","getAll","getAllKeys","count"],_o=["put","add","delete","clear"],fe=new Map;function bt(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&typeof t=="string"))return;if(fe.get(t))return fe.get(t);const n=t.replace(/FromIndex$/,""),r=t!==n,o=_o.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(o||Eo.includes(n)))return;const i=async function(s,...a){const c=this.transaction(s,o?"readwrite":"readonly");let d=c.store;return r&&(d=d.index(a.shift())),(await Promise.all([d[n](...a),o&&c.done]))[0]};return fe.set(t,i),i}mo(e=>({...e,get:(t,n,r)=>bt(t,n)||e.get(t,n,r),has:(t,n)=>!!bt(t,n)||e.has(t,n)}));const Gt="@firebase/installations",xe="0.6.4";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zt=1e4,Jt=`w:${xe}`,Yt="FIS_v2",Io="https://firebaseinstallations.googleapis.com/v1",To=60*60*1e3,vo="installations",Ao="Installations";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Do={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."},R=new G(vo,Ao,Do);function Xt(e){return e instanceof H&&e.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qt({projectId:e}){return`${Io}/projects/${e}/installations`}function Zt(e){return{token:e.token,requestStatus:2,expiresIn:Co(e.expiresIn),creationTime:Date.now()}}async function en(e,t){const r=(await t.json()).error;return R.create("request-failed",{requestName:e,serverCode:r.code,serverMessage:r.message,serverStatus:r.status})}function tn({apiKey:e}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e})}function ko(e,{refreshToken:t}){const n=tn(e);return n.append("Authorization",Oo(t)),n}async function nn(e){const t=await e();return t.status>=500&&t.status<600?e():t}function Co(e){return Number(e.replace("s","000"))}function Oo(e){return`${Yt} ${e}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function No({appConfig:e,heartbeatServiceProvider:t},{fid:n}){const r=Qt(e),o=tn(e),i=t.getImmediate({optional:!0});if(i){const d=await i.getHeartbeatsHeader();d&&o.append("x-firebase-client",d)}const s={fid:n,authVersion:Yt,appId:e.appId,sdkVersion:Jt},a={method:"POST",headers:o,body:JSON.stringify(s)},c=await nn(()=>fetch(r,a));if(c.ok){const d=await c.json();return{fid:d.fid||n,registrationStatus:2,refreshToken:d.refreshToken,authToken:Zt(d.authToken)}}else throw await en("Create Installation",c)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rn(e){return new Promise(t=>{setTimeout(t,e)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $o(e){return btoa(String.fromCharCode(...e)).replace(/\+/g,"-").replace(/\//g,"_")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mo=/^[cdef][\w-]{21}$/,Me="";function Bo(){try{const e=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(e),e[0]=112+e[0]%16;const n=Po(e);return Mo.test(n)?n:Me}catch{return Me}}function Po(e){return $o(e).substr(0,22)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function re(e){return`${e.appName}!${e.appId}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const on=new Map;function sn(e,t){const n=re(e);an(n,t),Ro(n,t)}function an(e,t){const n=on.get(e);if(n)for(const r of n)r(t)}function Ro(e,t){const n=Lo();n&&n.postMessage({key:e,fid:t}),Uo()}let $=null;function Lo(){return!$&&"BroadcastChannel"in self&&($=new BroadcastChannel("[Firebase] FID Change"),$.onmessage=e=>{an(e.data.key,e.data.fid)}),$}function Uo(){on.size===0&&$&&($.close(),$=null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fo="firebase-installations-database",jo=1,L="firebase-installations-store";let he=null;function He(){return he||(he=So(Fo,jo,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(L)}}})),he}async function ee(e,t){const n=re(e),o=(await He()).transaction(L,"readwrite"),i=o.objectStore(L),s=await i.get(n);return await i.put(t,n),await o.done,(!s||s.fid!==t.fid)&&sn(e,t.fid),t}async function cn(e){const t=re(e),r=(await He()).transaction(L,"readwrite");await r.objectStore(L).delete(t),await r.done}async function oe(e,t){const n=re(e),o=(await He()).transaction(L,"readwrite"),i=o.objectStore(L),s=await i.get(n),a=t(s);return a===void 0?await i.delete(n):await i.put(a,n),await o.done,a&&(!s||s.fid!==a.fid)&&sn(e,a.fid),a}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ke(e){let t;const n=await oe(e.appConfig,r=>{const o=xo(r),i=Ho(e,o);return t=i.registrationPromise,i.installationEntry});return n.fid===Me?{installationEntry:await t}:{installationEntry:n,registrationPromise:t}}function xo(e){const t=e||{fid:Bo(),registrationStatus:0};return un(t)}function Ho(e,t){if(t.registrationStatus===0){if(!navigator.onLine){const o=Promise.reject(R.create("app-offline"));return{installationEntry:t,registrationPromise:o}}const n={fid:t.fid,registrationStatus:1,registrationTime:Date.now()},r=Ko(e,n);return{installationEntry:n,registrationPromise:r}}else return t.registrationStatus===1?{installationEntry:t,registrationPromise:Vo(e)}:{installationEntry:t}}async function Ko(e,t){try{const n=await No(e,t);return ee(e.appConfig,n)}catch(n){throw Xt(n)&&n.customData.serverCode===409?await cn(e.appConfig):await ee(e.appConfig,{fid:t.fid,registrationStatus:0}),n}}async function Vo(e){let t=await mt(e.appConfig);for(;t.registrationStatus===1;)await rn(100),t=await mt(e.appConfig);if(t.registrationStatus===0){const{installationEntry:n,registrationPromise:r}=await Ke(e);return r||n}return t}function mt(e){return oe(e,t=>{if(!t)throw R.create("installation-not-found");return un(t)})}function un(e){return Wo(e)?{fid:e.fid,registrationStatus:0}:e}function Wo(e){return e.registrationStatus===1&&e.registrationTime+zt<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function qo({appConfig:e,heartbeatServiceProvider:t},n){const r=Go(e,n),o=ko(e,n),i=t.getImmediate({optional:!0});if(i){const d=await i.getHeartbeatsHeader();d&&o.append("x-firebase-client",d)}const s={installation:{sdkVersion:Jt,appId:e.appId}},a={method:"POST",headers:o,body:JSON.stringify(s)},c=await nn(()=>fetch(r,a));if(c.ok){const d=await c.json();return Zt(d)}else throw await en("Generate Auth Token",c)}function Go(e,{fid:t}){return`${Qt(e)}/${t}/authTokens:generate`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ve(e,t=!1){let n;const r=await oe(e.appConfig,i=>{if(!dn(i))throw R.create("not-registered");const s=i.authToken;if(!t&&Yo(s))return i;if(s.requestStatus===1)return n=zo(e,t),i;{if(!navigator.onLine)throw R.create("app-offline");const a=Qo(i);return n=Jo(e,a),a}});return n?await n:r.authToken}async function zo(e,t){let n=await wt(e.appConfig);for(;n.authToken.requestStatus===1;)await rn(100),n=await wt(e.appConfig);const r=n.authToken;return r.requestStatus===0?Ve(e,t):r}function wt(e){return oe(e,t=>{if(!dn(t))throw R.create("not-registered");const n=t.authToken;return Zo(n)?Object.assign(Object.assign({},t),{authToken:{requestStatus:0}}):t})}async function Jo(e,t){try{const n=await qo(e,t),r=Object.assign(Object.assign({},t),{authToken:n});return await ee(e.appConfig,r),n}catch(n){if(Xt(n)&&(n.customData.serverCode===401||n.customData.serverCode===404))await cn(e.appConfig);else{const r=Object.assign(Object.assign({},t),{authToken:{requestStatus:0}});await ee(e.appConfig,r)}throw n}}function dn(e){return e!==void 0&&e.registrationStatus===2}function Yo(e){return e.requestStatus===2&&!Xo(e)}function Xo(e){const t=Date.now();return t<e.creationTime||e.creationTime+e.expiresIn<t+To}function Qo(e){const t={requestStatus:1,requestTime:Date.now()};return Object.assign(Object.assign({},e),{authToken:t})}function Zo(e){return e.requestStatus===1&&e.requestTime+zt<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ei(e){const t=e,{installationEntry:n,registrationPromise:r}=await Ke(t);return r?r.catch(console.error):Ve(t).catch(console.error),n.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ti(e,t=!1){const n=e;return await ni(n),(await Ve(n,t)).token}async function ni(e){const{registrationPromise:t}=await Ke(e);t&&await t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ri(e){if(!e||!e.options)throw pe("App Configuration");if(!e.name)throw pe("App Name");const t=["projectId","apiKey","appId"];for(const n of t)if(!e.options[n])throw pe(n);return{appName:e.name,projectId:e.options.projectId,apiKey:e.options.apiKey,appId:e.options.appId}}function pe(e){return R.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ln="installations",oi="installations-internal",ii=e=>{const t=e.getProvider("app").getImmediate(),n=ri(t),r=Fe(t,"heartbeat");return{app:t,appConfig:n,heartbeatServiceProvider:r,_delete:()=>Promise.resolve()}},si=e=>{const t=e.getProvider("app").getImmediate(),n=Fe(t,ln).getImmediate();return{getId:()=>ei(n),getToken:o=>ti(n,o)}};function ai(){C(new _(ln,ii,"PUBLIC")),C(new _(oi,si,"PRIVATE"))}ai();D(Gt,xe);D(Gt,xe,"esm2017");const ci=(e,t)=>t.some(n=>e instanceof n);let yt,St;function ui(){return yt||(yt=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function di(){return St||(St=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const fn=new WeakMap,Be=new WeakMap,hn=new WeakMap,ge=new WeakMap,We=new WeakMap;function li(e){const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("success",i),e.removeEventListener("error",s)},i=()=>{n(E(e.result)),o()},s=()=>{r(e.error),o()};e.addEventListener("success",i),e.addEventListener("error",s)});return t.then(n=>{n instanceof IDBCursor&&fn.set(n,e)}).catch(()=>{}),We.set(t,e),t}function fi(e){if(Be.has(e))return;const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("complete",i),e.removeEventListener("error",s),e.removeEventListener("abort",s)},i=()=>{n(),o()},s=()=>{r(e.error||new DOMException("AbortError","AbortError")),o()};e.addEventListener("complete",i),e.addEventListener("error",s),e.addEventListener("abort",s)});Be.set(e,t)}let Pe={get(e,t,n){if(e instanceof IDBTransaction){if(t==="done")return Be.get(e);if(t==="objectStoreNames")return e.objectStoreNames||hn.get(e);if(t==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return E(e[t])},set(e,t,n){return e[t]=n,!0},has(e,t){return e instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in e}};function hi(e){Pe=e(Pe)}function pi(e){return e===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(t,...n){const r=e.call(be(this),t,...n);return hn.set(r,t.sort?t.sort():[t]),E(r)}:di().includes(e)?function(...t){return e.apply(be(this),t),E(fn.get(this))}:function(...t){return E(e.apply(be(this),t))}}function gi(e){return typeof e=="function"?pi(e):(e instanceof IDBTransaction&&fi(e),ci(e,ui())?new Proxy(e,Pe):e)}function E(e){if(e instanceof IDBRequest)return li(e);if(ge.has(e))return ge.get(e);const t=gi(e);return t!==e&&(ge.set(e,t),We.set(t,e)),t}const be=e=>We.get(e);function ie(e,t,{blocked:n,upgrade:r,blocking:o,terminated:i}={}){const s=indexedDB.open(e,t),a=E(s);return r&&s.addEventListener("upgradeneeded",c=>{r(E(s.result),c.oldVersion,c.newVersion,E(s.transaction))}),n&&s.addEventListener("blocked",()=>n()),a.then(c=>{i&&c.addEventListener("close",()=>i()),o&&c.addEventListener("versionchange",()=>o())}).catch(()=>{}),a}function x(e,{blocked:t}={}){const n=indexedDB.deleteDatabase(e);return t&&n.addEventListener("blocked",()=>t()),E(n).then(()=>{})}const bi=["get","getKey","getAll","getAllKeys","count"],mi=["put","add","delete","clear"],me=new Map;function Et(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&typeof t=="string"))return;if(me.get(t))return me.get(t);const n=t.replace(/FromIndex$/,""),r=t!==n,o=mi.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(o||bi.includes(n)))return;const i=async function(s,...a){const c=this.transaction(s,o?"readwrite":"readonly");let d=c.store;return r&&(d=d.index(a.shift())),(await Promise.all([d[n](...a),o&&c.done]))[0]};return me.set(t,i),i}hi(e=>({...e,get:(t,n,r)=>Et(t,n)||e.get(t,n,r),has:(t,n)=>!!Et(t,n)||e.has(t,n)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pn="BDOU99-h67HcA6JeFXHbSNMu7e2yNNu3RzoMj8TM4W88jITfq7ZmPvIM1Iv-4_l2LxQcYwhqby2xGpWwzjfAnG4",wi="https://fcmregistrations.googleapis.com/v1",gn="FCM_MSG",yi="google.c.a.c_id",Si=3,Ei=1;var te;(function(e){e[e.DATA_MESSAGE=1]="DATA_MESSAGE",e[e.DISPLAY_NOTIFICATION=3]="DISPLAY_NOTIFICATION"})(te||(te={}));/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */var ne;(function(e){e.PUSH_RECEIVED="push-received",e.NOTIFICATION_CLICKED="notification-clicked"})(ne||(ne={}));/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function y(e){const t=new Uint8Array(e);return btoa(String.fromCharCode(...t)).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_")}function _i(e){const t="=".repeat((4-e.length%4)%4),n=(e+t).replace(/\-/g,"+").replace(/_/g,"/"),r=atob(n),o=new Uint8Array(r.length);for(let i=0;i<r.length;++i)o[i]=r.charCodeAt(i);return o}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const we="fcm_token_details_db",Ii=5,_t="fcm_token_object_Store";async function Ti(e){if("databases"in indexedDB&&!(await indexedDB.databases()).map(i=>i.name).includes(we))return null;let t=null;return(await ie(we,Ii,{upgrade:async(r,o,i,s)=>{var a;if(o<2||!r.objectStoreNames.contains(_t))return;const c=s.objectStore(_t),d=await c.index("fcmSenderId").get(e);if(await c.clear(),!!d){if(o===2){const u=d;if(!u.auth||!u.p256dh||!u.endpoint)return;t={token:u.fcmToken,createTime:(a=u.createTime)!==null&&a!==void 0?a:Date.now(),subscriptionOptions:{auth:u.auth,p256dh:u.p256dh,endpoint:u.endpoint,swScope:u.swScope,vapidKey:typeof u.vapidKey=="string"?u.vapidKey:y(u.vapidKey)}}}else if(o===3){const u=d;t={token:u.fcmToken,createTime:u.createTime,subscriptionOptions:{auth:y(u.auth),p256dh:y(u.p256dh),endpoint:u.endpoint,swScope:u.swScope,vapidKey:y(u.vapidKey)}}}else if(o===4){const u=d;t={token:u.fcmToken,createTime:u.createTime,subscriptionOptions:{auth:y(u.auth),p256dh:y(u.p256dh),endpoint:u.endpoint,swScope:u.swScope,vapidKey:y(u.vapidKey)}}}}}})).close(),await x(we),await x("fcm_vapid_details_db"),await x("undefined"),vi(t)?t:null}function vi(e){if(!e||!e.subscriptionOptions)return!1;const{subscriptionOptions:t}=e;return typeof e.createTime=="number"&&e.createTime>0&&typeof e.token=="string"&&e.token.length>0&&typeof t.auth=="string"&&t.auth.length>0&&typeof t.p256dh=="string"&&t.p256dh.length>0&&typeof t.endpoint=="string"&&t.endpoint.length>0&&typeof t.swScope=="string"&&t.swScope.length>0&&typeof t.vapidKey=="string"&&t.vapidKey.length>0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ai="firebase-messaging-database",Di=1,U="firebase-messaging-store";let ye=null;function qe(){return ye||(ye=ie(Ai,Di,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(U)}}})),ye}async function Ge(e){const t=Je(e),r=await(await qe()).transaction(U).objectStore(U).get(t);if(r)return r;{const o=await Ti(e.appConfig.senderId);if(o)return await ze(e,o),o}}async function ze(e,t){const n=Je(e),o=(await qe()).transaction(U,"readwrite");return await o.objectStore(U).put(t,n),await o.done,t}async function ki(e){const t=Je(e),r=(await qe()).transaction(U,"readwrite");await r.objectStore(U).delete(t),await r.done}function Je({appConfig:e}){return e.appId}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ci={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"only-available-in-window":"This method is available in a Window context.","only-available-in-sw":"This method is available in a service worker context.","permission-default":"The notification permission was not granted and dismissed instead.","permission-blocked":"The notification permission was not granted and blocked instead.","unsupported-browser":"This browser doesn't support the API's required to use the Firebase SDK.","indexed-db-unsupported":"This browser doesn't support indexedDb.open() (ex. Safari iFrame, Firefox Private Browsing, etc)","failed-service-worker-registration":"We are unable to register the default service worker. {$browserErrorMessage}","token-subscribe-failed":"A problem occurred while subscribing the user to FCM: {$errorInfo}","token-subscribe-no-token":"FCM returned no token when subscribing the user to push.","token-unsubscribe-failed":"A problem occurred while unsubscribing the user from FCM: {$errorInfo}","token-update-failed":"A problem occurred while updating the user from FCM: {$errorInfo}","token-update-no-token":"FCM returned no token when updating the user to push.","use-sw-after-get-token":"The useServiceWorker() method may only be called once and must be called before calling getToken() to ensure your service worker is used.","invalid-sw-registration":"The input to useServiceWorker() must be a ServiceWorkerRegistration.","invalid-bg-handler":"The input to setBackgroundMessageHandler() must be a function.","invalid-vapid-key":"The public VAPID key must be a string.","use-vapid-key-after-get-token":"The usePublicVapidKey() method may only be called once and must be called before calling getToken() to ensure your VAPID key is used."},w=new G("messaging","Messaging",Ci);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Oi(e,t){const n=await Xe(e),r=mn(t),o={method:"POST",headers:n,body:JSON.stringify(r)};let i;try{i=await(await fetch(Ye(e.appConfig),o)).json()}catch(s){throw w.create("token-subscribe-failed",{errorInfo:s==null?void 0:s.toString()})}if(i.error){const s=i.error.message;throw w.create("token-subscribe-failed",{errorInfo:s})}if(!i.token)throw w.create("token-subscribe-no-token");return i.token}async function Ni(e,t){const n=await Xe(e),r=mn(t.subscriptionOptions),o={method:"PATCH",headers:n,body:JSON.stringify(r)};let i;try{i=await(await fetch(`${Ye(e.appConfig)}/${t.token}`,o)).json()}catch(s){throw w.create("token-update-failed",{errorInfo:s==null?void 0:s.toString()})}if(i.error){const s=i.error.message;throw w.create("token-update-failed",{errorInfo:s})}if(!i.token)throw w.create("token-update-no-token");return i.token}async function bn(e,t){const r={method:"DELETE",headers:await Xe(e)};try{const i=await(await fetch(`${Ye(e.appConfig)}/${t}`,r)).json();if(i.error){const s=i.error.message;throw w.create("token-unsubscribe-failed",{errorInfo:s})}}catch(o){throw w.create("token-unsubscribe-failed",{errorInfo:o==null?void 0:o.toString()})}}function Ye({projectId:e}){return`${wi}/projects/${e}/registrations`}async function Xe({appConfig:e,installations:t}){const n=await t.getToken();return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e.apiKey,"x-goog-firebase-installations-auth":`FIS ${n}`})}function mn({p256dh:e,auth:t,endpoint:n,vapidKey:r}){const o={web:{endpoint:n,auth:t,p256dh:e}};return r!==pn&&(o.web.applicationPubKey=r),o}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $i=7*24*60*60*1e3;async function Mi(e){const t=await Pi(e.swRegistration,e.vapidKey),n={vapidKey:e.vapidKey,swScope:e.swRegistration.scope,endpoint:t.endpoint,auth:y(t.getKey("auth")),p256dh:y(t.getKey("p256dh"))},r=await Ge(e.firebaseDependencies);if(r){if(Ri(r.subscriptionOptions,n))return Date.now()>=r.createTime+$i?Bi(e,{token:r.token,createTime:Date.now(),subscriptionOptions:n}):r.token;try{await bn(e.firebaseDependencies,r.token)}catch(o){console.warn(o)}return It(e.firebaseDependencies,n)}else return It(e.firebaseDependencies,n)}async function Re(e){const t=await Ge(e.firebaseDependencies);t&&(await bn(e.firebaseDependencies,t.token),await ki(e.firebaseDependencies));const n=await e.swRegistration.pushManager.getSubscription();return n?n.unsubscribe():!0}async function Bi(e,t){try{const n=await Ni(e.firebaseDependencies,t),r=Object.assign(Object.assign({},t),{token:n,createTime:Date.now()});return await ze(e.firebaseDependencies,r),n}catch(n){throw await Re(e),n}}async function It(e,t){const r={token:await Oi(e,t),createTime:Date.now(),subscriptionOptions:t};return await ze(e,r),r.token}async function Pi(e,t){const n=await e.pushManager.getSubscription();return n||e.pushManager.subscribe({userVisibleOnly:!0,applicationServerKey:_i(t)})}function Ri(e,t){const n=t.vapidKey===e.vapidKey,r=t.endpoint===e.endpoint,o=t.auth===e.auth,i=t.p256dh===e.p256dh;return n&&r&&o&&i}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Li(e){const t={from:e.from,collapseKey:e.collapse_key,messageId:e.fcmMessageId};return Ui(t,e),Fi(t,e),ji(t,e),t}function Ui(e,t){if(!t.notification)return;e.notification={};const n=t.notification.title;n&&(e.notification.title=n);const r=t.notification.body;r&&(e.notification.body=r);const o=t.notification.image;o&&(e.notification.image=o);const i=t.notification.icon;i&&(e.notification.icon=i)}function Fi(e,t){t.data&&(e.data=t.data)}function ji(e,t){var n,r,o,i,s;if(!t.fcmOptions&&!(!((n=t.notification)===null||n===void 0)&&n.click_action))return;e.fcmOptions={};const a=(o=(r=t.fcmOptions)===null||r===void 0?void 0:r.link)!==null&&o!==void 0?o:(i=t.notification)===null||i===void 0?void 0:i.click_action;a&&(e.fcmOptions.link=a);const c=(s=t.fcmOptions)===null||s===void 0?void 0:s.analytics_label;c&&(e.fcmOptions.analyticsLabel=c)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xi(e){return typeof e=="object"&&!!e&&yi in e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Hi(e){return new Promise(t=>{setTimeout(t,e)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */wn("hts/frbslgigp.ogepscmv/ieo/eaylg","tp:/ieaeogn-agolai.o/1frlglgc/o");wn("AzSCbw63g1R0nCw85jG8","Iaya3yLKwmgvh7cF0q4");async function Ki(e,t){const n=Vi(t,await e.firebaseDependencies.installations.getId());Wi(e,n)}function Vi(e,t){var n,r;const o={};return e.from&&(o.project_number=e.from),e.fcmMessageId&&(o.message_id=e.fcmMessageId),o.instance_id=t,e.notification?o.message_type=te.DISPLAY_NOTIFICATION.toString():o.message_type=te.DATA_MESSAGE.toString(),o.sdk_platform=Si.toString(),o.package_name=self.origin.replace(/(^\w+:|^)\/\//,""),e.collapse_key&&(o.collapse_key=e.collapse_key),o.event=Ei.toString(),!((n=e.fcmOptions)===null||n===void 0)&&n.analytics_label&&(o.analytics_label=(r=e.fcmOptions)===null||r===void 0?void 0:r.analytics_label),o}function Wi(e,t){const n={};n.event_time_ms=Math.floor(Date.now()).toString(),n.source_extension_json_proto3=JSON.stringify(t),e.logEvents.push(n)}function wn(e,t){const n=[];for(let r=0;r<e.length;r++)n.push(e.charAt(r)),r<t.length&&n.push(t.charAt(r));return n.join("")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function qi(e,t){var n,r;const{newSubscription:o}=e;if(!o){await Re(t);return}const i=await Ge(t.firebaseDependencies);await Re(t),t.vapidKey=(r=(n=i==null?void 0:i.subscriptionOptions)===null||n===void 0?void 0:n.vapidKey)!==null&&r!==void 0?r:pn,await Mi(t)}async function Gi(e,t){const n=Yi(e);if(!n)return;t.deliveryMetricsExportedToBigQueryEnabled&&await Ki(t,n);const r=await yn();if(Qi(r))return Zi(r,n);if(n.notification&&await es(Ji(n)),!!t&&t.onBackgroundMessageHandler){const o=Li(n);typeof t.onBackgroundMessageHandler=="function"?await t.onBackgroundMessageHandler(o):t.onBackgroundMessageHandler.next(o)}}async function zi(e){var t,n;const r=(n=(t=e.notification)===null||t===void 0?void 0:t.data)===null||n===void 0?void 0:n[gn];if(r){if(e.action)return}else return;e.stopImmediatePropagation(),e.notification.close();const o=ts(r);if(!o)return;const i=new URL(o,self.location.href),s=new URL(self.location.origin);if(i.host!==s.host)return;let a=await Xi(i);if(a?a=await a.focus():(a=await self.clients.openWindow(o),await Hi(3e3)),!!a)return r.messageType=ne.NOTIFICATION_CLICKED,r.isFirebaseMessaging=!0,a.postMessage(r)}function Ji(e){const t=Object.assign({},e.notification);return t.data={[gn]:e},t}function Yi({data:e}){if(!e)return null;try{return e.json()}catch{return null}}async function Xi(e){const t=await yn();for(const n of t){const r=new URL(n.url,self.location.href);if(e.host===r.host)return n}return null}function Qi(e){return e.some(t=>t.visibilityState==="visible"&&!t.url.startsWith("chrome-extension://"))}function Zi(e,t){t.isFirebaseMessaging=!0,t.messageType=ne.PUSH_RECEIVED;for(const n of e)n.postMessage(t)}function yn(){return self.clients.matchAll({type:"window",includeUncontrolled:!0})}function es(e){var t;const{actions:n}=e,{maxActions:r}=Notification;return n&&r&&n.length>r&&console.warn(`This browser only supports ${r} actions. The remaining actions will not be displayed.`),self.registration.showNotification((t=e.title)!==null&&t!==void 0?t:"",e)}function ts(e){var t,n,r;const o=(n=(t=e.fcmOptions)===null||t===void 0?void 0:t.link)!==null&&n!==void 0?n:(r=e.notification)===null||r===void 0?void 0:r.click_action;return o||(xi(e.data)?self.location.origin:null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ns(e){if(!e||!e.options)throw Se("App Configuration Object");if(!e.name)throw Se("App Name");const t=["projectId","apiKey","appId","messagingSenderId"],{options:n}=e;for(const r of t)if(!n[r])throw Se(r);return{appName:e.name,projectId:n.projectId,apiKey:n.apiKey,appId:n.appId,senderId:n.messagingSenderId}}function Se(e){return w.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let rs=class{constructor(t,n,r){this.deliveryMetricsExportedToBigQueryEnabled=!1,this.onBackgroundMessageHandler=null,this.onMessageHandler=null,this.logEvents=[],this.isLogServiceStarted=!1;const o=ns(t);this.firebaseDependencies={app:t,appConfig:o,installations:n,analyticsProvider:r}}_delete(){return Promise.resolve()}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const os=e=>{const t=new rs(e.getProvider("app").getImmediate(),e.getProvider("installations-internal").getImmediate(),e.getProvider("analytics-internal"));return self.addEventListener("push",n=>{n.waitUntil(Gi(n,t))}),self.addEventListener("pushsubscriptionchange",n=>{n.waitUntil(qi(n,t))}),self.addEventListener("notificationclick",n=>{n.waitUntil(zi(n))}),t};function is(){C(new _("messaging-sw",os,"PUBLIC"))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ss(){return Lt()&&await Ut()&&"PushManager"in self&&"Notification"in self&&ServiceWorkerRegistration.prototype.hasOwnProperty("showNotification")&&PushSubscription.prototype.hasOwnProperty("getKey")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function as(e=Zr()){return ss().then(t=>{if(!t)throw w.create("unsupported-browser")},t=>{throw w.create("indexed-db-unsupported")}),Fe(Ft(e),"messaging-sw").getImmediate()}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */is();/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cs="/firebase-messaging-sw.js",us="/firebase-cloud-messaging-push-scope",Sn="BDOU99-h67HcA6JeFXHbSNMu7e2yNNu3RzoMj8TM4W88jITfq7ZmPvIM1Iv-4_l2LxQcYwhqby2xGpWwzjfAnG4",ds="https://fcmregistrations.googleapis.com/v1",En="google.c.a.c_id",ls="google.c.a.c_l",fs="google.c.a.ts",hs="google.c.a.e";var Tt;(function(e){e[e.DATA_MESSAGE=1]="DATA_MESSAGE",e[e.DISPLAY_NOTIFICATION=3]="DISPLAY_NOTIFICATION"})(Tt||(Tt={}));/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */var q;(function(e){e.PUSH_RECEIVED="push-received",e.NOTIFICATION_CLICKED="notification-clicked"})(q||(q={}));/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function S(e){const t=new Uint8Array(e);return btoa(String.fromCharCode(...t)).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_")}function ps(e){const t="=".repeat((4-e.length%4)%4),n=(e+t).replace(/\-/g,"+").replace(/_/g,"/"),r=atob(n),o=new Uint8Array(r.length);for(let i=0;i<r.length;++i)o[i]=r.charCodeAt(i);return o}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ee="fcm_token_details_db",gs=5,vt="fcm_token_object_Store";async function bs(e){if("databases"in indexedDB&&!(await indexedDB.databases()).map(i=>i.name).includes(Ee))return null;let t=null;return(await ie(Ee,gs,{upgrade:async(r,o,i,s)=>{var a;if(o<2||!r.objectStoreNames.contains(vt))return;const c=s.objectStore(vt),d=await c.index("fcmSenderId").get(e);if(await c.clear(),!!d){if(o===2){const u=d;if(!u.auth||!u.p256dh||!u.endpoint)return;t={token:u.fcmToken,createTime:(a=u.createTime)!==null&&a!==void 0?a:Date.now(),subscriptionOptions:{auth:u.auth,p256dh:u.p256dh,endpoint:u.endpoint,swScope:u.swScope,vapidKey:typeof u.vapidKey=="string"?u.vapidKey:S(u.vapidKey)}}}else if(o===3){const u=d;t={token:u.fcmToken,createTime:u.createTime,subscriptionOptions:{auth:S(u.auth),p256dh:S(u.p256dh),endpoint:u.endpoint,swScope:u.swScope,vapidKey:S(u.vapidKey)}}}else if(o===4){const u=d;t={token:u.fcmToken,createTime:u.createTime,subscriptionOptions:{auth:S(u.auth),p256dh:S(u.p256dh),endpoint:u.endpoint,swScope:u.swScope,vapidKey:S(u.vapidKey)}}}}}})).close(),await x(Ee),await x("fcm_vapid_details_db"),await x("undefined"),ms(t)?t:null}function ms(e){if(!e||!e.subscriptionOptions)return!1;const{subscriptionOptions:t}=e;return typeof e.createTime=="number"&&e.createTime>0&&typeof e.token=="string"&&e.token.length>0&&typeof t.auth=="string"&&t.auth.length>0&&typeof t.p256dh=="string"&&t.p256dh.length>0&&typeof t.endpoint=="string"&&t.endpoint.length>0&&typeof t.swScope=="string"&&t.swScope.length>0&&typeof t.vapidKey=="string"&&t.vapidKey.length>0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ws="firebase-messaging-database",ys=1,F="firebase-messaging-store";let _e=null;function Qe(){return _e||(_e=ie(ws,ys,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(F)}}})),_e}async function _n(e){const t=et(e),r=await(await Qe()).transaction(F).objectStore(F).get(t);if(r)return r;{const o=await bs(e.appConfig.senderId);if(o)return await Ze(e,o),o}}async function Ze(e,t){const n=et(e),o=(await Qe()).transaction(F,"readwrite");return await o.objectStore(F).put(t,n),await o.done,t}async function Ss(e){const t=et(e),r=(await Qe()).transaction(F,"readwrite");await r.objectStore(F).delete(t),await r.done}function et({appConfig:e}){return e.appId}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Es={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"only-available-in-window":"This method is available in a Window context.","only-available-in-sw":"This method is available in a service worker context.","permission-default":"The notification permission was not granted and dismissed instead.","permission-blocked":"The notification permission was not granted and blocked instead.","unsupported-browser":"This browser doesn't support the API's required to use the Firebase SDK.","indexed-db-unsupported":"This browser doesn't support indexedDb.open() (ex. Safari iFrame, Firefox Private Browsing, etc)","failed-service-worker-registration":"We are unable to register the default service worker. {$browserErrorMessage}","token-subscribe-failed":"A problem occurred while subscribing the user to FCM: {$errorInfo}","token-subscribe-no-token":"FCM returned no token when subscribing the user to push.","token-unsubscribe-failed":"A problem occurred while unsubscribing the user from FCM: {$errorInfo}","token-update-failed":"A problem occurred while updating the user from FCM: {$errorInfo}","token-update-no-token":"FCM returned no token when updating the user to push.","use-sw-after-get-token":"The useServiceWorker() method may only be called once and must be called before calling getToken() to ensure your service worker is used.","invalid-sw-registration":"The input to useServiceWorker() must be a ServiceWorkerRegistration.","invalid-bg-handler":"The input to setBackgroundMessageHandler() must be a function.","invalid-vapid-key":"The public VAPID key must be a string.","use-vapid-key-after-get-token":"The usePublicVapidKey() method may only be called once and must be called before calling getToken() to ensure your VAPID key is used."},m=new G("messaging","Messaging",Es);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function _s(e,t){const n=await nt(e),r=Tn(t),o={method:"POST",headers:n,body:JSON.stringify(r)};let i;try{i=await(await fetch(tt(e.appConfig),o)).json()}catch(s){throw m.create("token-subscribe-failed",{errorInfo:s==null?void 0:s.toString()})}if(i.error){const s=i.error.message;throw m.create("token-subscribe-failed",{errorInfo:s})}if(!i.token)throw m.create("token-subscribe-no-token");return i.token}async function Is(e,t){const n=await nt(e),r=Tn(t.subscriptionOptions),o={method:"PATCH",headers:n,body:JSON.stringify(r)};let i;try{i=await(await fetch(`${tt(e.appConfig)}/${t.token}`,o)).json()}catch(s){throw m.create("token-update-failed",{errorInfo:s==null?void 0:s.toString()})}if(i.error){const s=i.error.message;throw m.create("token-update-failed",{errorInfo:s})}if(!i.token)throw m.create("token-update-no-token");return i.token}async function In(e,t){const r={method:"DELETE",headers:await nt(e)};try{const i=await(await fetch(`${tt(e.appConfig)}/${t}`,r)).json();if(i.error){const s=i.error.message;throw m.create("token-unsubscribe-failed",{errorInfo:s})}}catch(o){throw m.create("token-unsubscribe-failed",{errorInfo:o==null?void 0:o.toString()})}}function tt({projectId:e}){return`${ds}/projects/${e}/registrations`}async function nt({appConfig:e,installations:t}){const n=await t.getToken();return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e.apiKey,"x-goog-firebase-installations-auth":`FIS ${n}`})}function Tn({p256dh:e,auth:t,endpoint:n,vapidKey:r}){const o={web:{endpoint:n,auth:t,p256dh:e}};return r!==Sn&&(o.web.applicationPubKey=r),o}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ts=7*24*60*60*1e3;async function vs(e){const t=await ks(e.swRegistration,e.vapidKey),n={vapidKey:e.vapidKey,swScope:e.swRegistration.scope,endpoint:t.endpoint,auth:S(t.getKey("auth")),p256dh:S(t.getKey("p256dh"))},r=await _n(e.firebaseDependencies);if(r){if(Cs(r.subscriptionOptions,n))return Date.now()>=r.createTime+Ts?Ds(e,{token:r.token,createTime:Date.now(),subscriptionOptions:n}):r.token;try{await In(e.firebaseDependencies,r.token)}catch(o){console.warn(o)}return At(e.firebaseDependencies,n)}else return At(e.firebaseDependencies,n)}async function As(e){const t=await _n(e.firebaseDependencies);t&&(await In(e.firebaseDependencies,t.token),await Ss(e.firebaseDependencies));const n=await e.swRegistration.pushManager.getSubscription();return n?n.unsubscribe():!0}async function Ds(e,t){try{const n=await Is(e.firebaseDependencies,t),r=Object.assign(Object.assign({},t),{token:n,createTime:Date.now()});return await Ze(e.firebaseDependencies,r),n}catch(n){throw await As(e),n}}async function At(e,t){const r={token:await _s(e,t),createTime:Date.now(),subscriptionOptions:t};return await Ze(e,r),r.token}async function ks(e,t){const n=await e.pushManager.getSubscription();return n||e.pushManager.subscribe({userVisibleOnly:!0,applicationServerKey:ps(t)})}function Cs(e,t){const n=t.vapidKey===e.vapidKey,r=t.endpoint===e.endpoint,o=t.auth===e.auth,i=t.p256dh===e.p256dh;return n&&r&&o&&i}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Dt(e){const t={from:e.from,collapseKey:e.collapse_key,messageId:e.fcmMessageId};return Os(t,e),Ns(t,e),$s(t,e),t}function Os(e,t){if(!t.notification)return;e.notification={};const n=t.notification.title;n&&(e.notification.title=n);const r=t.notification.body;r&&(e.notification.body=r);const o=t.notification.image;o&&(e.notification.image=o);const i=t.notification.icon;i&&(e.notification.icon=i)}function Ns(e,t){t.data&&(e.data=t.data)}function $s(e,t){var n,r,o,i,s;if(!t.fcmOptions&&!(!((n=t.notification)===null||n===void 0)&&n.click_action))return;e.fcmOptions={};const a=(o=(r=t.fcmOptions)===null||r===void 0?void 0:r.link)!==null&&o!==void 0?o:(i=t.notification)===null||i===void 0?void 0:i.click_action;a&&(e.fcmOptions.link=a);const c=(s=t.fcmOptions)===null||s===void 0?void 0:s.analytics_label;c&&(e.fcmOptions.analyticsLabel=c)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ms(e){return typeof e=="object"&&!!e&&En in e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */vn("hts/frbslgigp.ogepscmv/ieo/eaylg","tp:/ieaeogn-agolai.o/1frlglgc/o");vn("AzSCbw63g1R0nCw85jG8","Iaya3yLKwmgvh7cF0q4");function vn(e,t){const n=[];for(let r=0;r<e.length;r++)n.push(e.charAt(r)),r<t.length&&n.push(t.charAt(r));return n.join("")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bs(e){if(!e||!e.options)throw Ie("App Configuration Object");if(!e.name)throw Ie("App Name");const t=["projectId","apiKey","appId","messagingSenderId"],{options:n}=e;for(const r of t)if(!n[r])throw Ie(r);return{appName:e.name,projectId:n.projectId,apiKey:n.apiKey,appId:n.appId,senderId:n.messagingSenderId}}function Ie(e){return m.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ps{constructor(t,n,r){this.deliveryMetricsExportedToBigQueryEnabled=!1,this.onBackgroundMessageHandler=null,this.onMessageHandler=null,this.logEvents=[],this.isLogServiceStarted=!1;const o=Bs(t);this.firebaseDependencies={app:t,appConfig:o,installations:n,analyticsProvider:r}}_delete(){return Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Rs(e){try{e.swRegistration=await navigator.serviceWorker.register(cs,{scope:us}),e.swRegistration.update().catch(()=>{})}catch(t){throw m.create("failed-service-worker-registration",{browserErrorMessage:t==null?void 0:t.message})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ls(e,t){if(!t&&!e.swRegistration&&await Rs(e),!(!t&&e.swRegistration)){if(!(t instanceof ServiceWorkerRegistration))throw m.create("invalid-sw-registration");e.swRegistration=t}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Us(e,t){t?e.vapidKey=t:e.vapidKey||(e.vapidKey=Sn)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function An(e,t){if(!navigator)throw m.create("only-available-in-window");if(Notification.permission==="default"&&await Notification.requestPermission(),Notification.permission!=="granted")throw m.create("permission-blocked");return await Us(e,t==null?void 0:t.vapidKey),await Ls(e,t==null?void 0:t.serviceWorkerRegistration),vs(e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Fs(e,t,n){const r=js(t);(await e.firebaseDependencies.analyticsProvider.get()).logEvent(r,{message_id:n[En],message_name:n[ls],message_time:n[fs],message_device_time:Math.floor(Date.now()/1e3)})}function js(e){switch(e){case q.NOTIFICATION_CLICKED:return"notification_open";case q.PUSH_RECEIVED:return"notification_foreground";default:throw new Error}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function xs(e,t){const n=t.data;if(!n.isFirebaseMessaging)return;e.onMessageHandler&&n.messageType===q.PUSH_RECEIVED&&(typeof e.onMessageHandler=="function"?e.onMessageHandler(Dt(n)):e.onMessageHandler.next(Dt(n)));const r=n.data;Ms(r)&&r[hs]==="1"&&await Fs(e,n.messageType,r)}const kt="@firebase/messaging",Ct="0.12.4";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hs=e=>{const t=new Ps(e.getProvider("app").getImmediate(),e.getProvider("installations-internal").getImmediate(),e.getProvider("analytics-internal"));return navigator.serviceWorker.addEventListener("message",n=>xs(t,n)),t},Ks=e=>{const t=e.getProvider("messaging").getImmediate();return{getToken:r=>An(t,r)}};function Vs(){C(new _("messaging",Hs,"PUBLIC")),C(new _("messaging-internal",Ks,"PRIVATE")),D(kt,Ct),D(kt,Ct,"esm2017")}async function Ws(e,t){return e=Ft(e),An(e,t)}Vs();const qs="/assets/index.js-loader-fe180b1e.js",T=$t();async function Gs(){const e=await da(),t=new Date().toDateString();if(!(e===null||new Date(e.requestDate).toDateString()!==t))return e.available;const r=await g(`${p}/cities`);if(!r.ok)return e===null?[]:e.available;const o=await r.json(),i={requestDate:t,available:o.available.map(s=>({id:s.id,name:s.name}))};return await O(Te,i),i.available}async function zs(e){const t=await On(),n=new URLSearchParams({cityId:`${t.id}`,url:e}),r=await g(`${p}/v1/products/scan?${n.toString()}`);if(!r.ok){const o=new Error("failed to retrieve data from the server");throw o.response=r,o}return await r.json()}async function Js(){try{const e=await g(`${p}/init`);if(!e.ok)return ot;const t=await e.json();return Cn(t.city)}catch{return ot}}async function Ys(e){const{authToken:t}=await I();if(!t)return{success:!1};const n={method:"POST",body:JSON.stringify(e)};return{success:(await g(`${p}/v1/products/subscriptions`,n)).ok}}async function Xs(e){const{authToken:t}=await I();if(!t)return{success:!1};const n={method:"DELETE",body:JSON.stringify(e)};return{success:(await g(`${p}/v1/products/subscriptions`,n)).ok}}async function Qs(e){const{authToken:t}=await I();if(!t)return await O(j,e),{success:!0};const n={method:"PUT",body:JSON.stringify({city_id:e.id})},r=await g(`${p}/user/city`,n);return r.ok?(await O(j,e),await r.json()):{success:!1}}async function Zs(e){const t={method:"POST",body:JSON.stringify(e)};await g(`${p}/v1/logs`,t)}async function ea(e){const t={method:"POST",body:JSON.stringify(e)};await g(`${p}/v1/events`,t)}async function ta(e){e.currentPageUrl=l.identity.getRedirectURL();const t={method:"POST",body:JSON.stringify(e)};return{success:(await g(`${p}/feedback`,t)).ok}}async function Dn(){const{authToken:e}=await I();if(!e)return null;const t=await g(`${p}/init`),{user:n}=await t.json(),r=kn(n);return await O(V,r),r.authUser}function na(){const e="https://accounts.google.com/o/oauth2/auth",t=l.identity.getRedirectURL().slice(0,-1),n={client_id:Un,redirect_uri:t,response_type:"code",scope:["email","profile"].join(" ")};T.info("Google auth params",{clientId:n.client_id,redirectUrl:n.redirect_uri,scope:n.scope});async function r(o){const i=new URL(o).searchParams.get("code"),s=`${p}/v1/auth/google`,a=await g(s,{method:"POST",body:JSON.stringify({code:i,clientType:"extension",redirectUrl:t})});if(!a.ok)throw new Error("Authentication failed");const c=await a.json();return rt(c)}return l.identity.launchWebAuthFlow({url:`${e}?${new URLSearchParams(n).toString()}`,interactive:!0}).then(r).catch(o=>({success:!1}))}async function ra(e){const t={method:"POST",body:JSON.stringify(e)},r=await(await g(`${p}/auth/user/create`,t)).json();return r.errors?{success:!1,errorMessages:r.errors}:rt(r)}async function oa(e){const t={method:"POST",body:JSON.stringify(e)},n=await g(`${p}/v1/auth/send-login-link`,t);return n.ok?{success:!0}:{success:!1,errorMessages:(await n.json()).errors}}async function ia(e){const t={method:"POST",body:JSON.stringify(e)},r=await(await g(`${p}/v1/auth/confirm`,t)).json();return r.errors||r.message==="Invalid code"?{success:!1,errorMessages:r.errors??{code:["validation.invalid"]}}:rt(r)}function rt(e){const{user:t,city:n}=e,r=kn(t),o=Cn(n);return{success:!0,userData:{authUserData:r,city:o}}}async function sa(e){const{authUserData:t,city:n}=e;return await Promise.all([O(V,t),O(j,n)]),{authUser:t.authUser,city:n}}async function aa(){try{const t=await g(`${p}/v1/auth/logout`,{method:"POST"});T.info("logout response",t.status)}catch(t){T.error("logout request failed"),T.captureException(t)}const e="https://accounts.google.com/o/oauth2/revoke?token=";try{const{token:t}=await l.identity.getAuthToken(),n=await fetch(e+t);T.info("google auth token was revoke",n.status)}catch{T.error("google auth token was empty")}await Promise.all([l.storage.local.remove(V),l.storage.local.remove(Q)])}async function ca(){const{userData:{authUser:e},city:t}=await ua();return{authUser:e,city:t}}function kn(e){if(e===null)return Nt;const t=e.subscriptions;return T.info("User info",{user:e,subscriptions:t}),{authToken:`${e.uuid}:${e.token}`,authUser:{email:e.email,id:e.id,isEmailConfirmed:e.isEmailConfirmed,telegramId:e.telegramId,telegramName:e.telegramName,telegramConnectUrl:e.telegramConnectUrl,subscriptions:{rozetkaProductCount:t.rozetkaProduct.length,alcoholProductCount:t.alcohol.length}}}}function Cn(e){return{id:e.id,name:e.name}}async function ua(){const[e,t]=await Promise.all([I(),On()]);return{userData:e,city:t}}async function I(){const{[V]:e}=await l.storage.local.get(V);return e?JSON.parse(e):Nt}async function On(){const{[j]:e}=await l.storage.local.get(j);if(!e){const t=await Js();return await O(j,t),t}return JSON.parse(e)}async function da(){const{[Te]:e}=await l.storage.local.get(Te);return e?JSON.parse(e):null}async function la(){const{[Q]:e}=await await l.storage.local.get(Q);return e?JSON.parse(e):""}async function O(e,t){await l.storage.local.set({[e]:JSON.stringify(t)})}async function fa(e){const{authToken:t}=await I();if(!t)return;const n=await la();if(T.info("Push token",{oldToken:n,newToken:e,changed:n!==e}),e===n)return;const r={method:"POST",body:JSON.stringify({token:e,client:"extension"})},o=await g(`${p}/v1/user/push-token`,r);return o.ok&&await O(Q,e),{success:o.ok}}async function g(e,t=null){const n=t??{method:"GET"};n.credentials="omit";const r=new Headers(n.headers??{}),{authToken:o}=await I();return o&&r.append("Authorization",o),r.append("X-App-Agent",ma()),r.append("Content-Type","application/json"),n.headers=r,await fetch(e,n)}function ha(e){const t=new Map;return{getResponseObjFromCache:n=>t.get(n),removeResponseObjFromCache:n=>t.delete(n),createNewResponseObj:(n,r,o={})=>{const i={requestUrl:r,error:!1,promiseObj:s(),reason:null};async function s(){var a;try{return await e(r,o)}catch(c){return((a=c.response)==null?void 0:a.status)===404&&(t.set(n,i),i.reason=404),i.error=!0,{error:"Bad response status code"}}}return t.set(n,i),i}}}const b=$t();b.info("background is running");l.runtime.onInstalled.addListener(async()=>{b.info("Background script was installed or updated");const e="main-content-script",t=await l.scripting.getRegisteredContentScripts({ids:[e]});if(b.info("REGISTER SCRIPTS",t),t.length){b.info("Scripts are already registered");return}b.info("Registering scripts...");const n=[];for(const o of M.iterShopHostRules())n.push(`https://${o}/*`);const r=[{matches:n,js:[qs],id:e,runAt:"document_end"}];try{await l.scripting.registerContentScripts(r)}catch(o){b.error("Failed to register scripts"),b.captureException(o)}});l.action.onClicked.addListener(async e=>{const t={type:B.OPEN_EXTENSION_DATA};await J(e.id,t)});const Le=ha(zs),z=e=>{Le.removeResponseObjFromCache(e)},Nn=(e,t)=>{const n=new URL(t);n.hash="";const r=n.href;let o=Le.getResponseObjFromCache(e);return((o==null?void 0:o.requestUrl)!==r||o.error&&o.reason!==404)&&(o=Le.createNewResponseObj(e,r)),o},Ot=async(e,t,n=!1)=>{const r=l.runtime.getURL(n?"img/logo-128.png":"img/logo-128-disabled.png");if(await l.action.setIcon({tabId:e,path:r}),!t){await l.action.setBadgeText({tabId:e,text:""});return}const o=t>0?it.ABOVE_MINIMUM_PRICE:it.BEST_PRICE;await l.action.setBadgeText({tabId:e,text:`${t}%`}),await l.action.setBadgeBackgroundColor({tabId:e,color:o})};l.tabs.onUpdated.addListener(async(e,t,n)=>{if(t.status!=="loading")return;const r=t.url??n.url;if(!M.isSupportedUrl(r)){z(e);try{await Ot(e,0,M.isSupportedHost(r))}catch{}return}const i=await Nn(e,r).promiseObj,s=M.findShopIdByUrl(r),a=Fn(i.shops??[],s);try{await Ot(e,a,!0)}catch{}});l.tabs.onRemoved.addListener(z);l.runtime.onMessage.addListener((e,t,n)=>{switch(b.info("onMessage",e),e.type){case h.FETCH_PRODUCT_DETAILS:const r=t.tab.id,o=e.url;Nn(r,o).promiseObj.then(a=>n(a));break;case h.SIGN_IN_USE_GOOGLE:na().then(a=>n(a));break;case h.SIGN_UP_USE_BADSELLER_ACCOUNT:ra(e.requestBody).then(a=>n(a));break;case h.LOGIN:sa(e.userData).then(a=>n(a));break;case h.SIGN_OUT_OF_ACCOUNT:aa().then(a=>n(a));break;case h.VERIFY_THE_ACCOUNT_EXISTS:oa(e.requestBody).then(a=>n(a));break;case h.GET_USER_DATA:ca().then(a=>n(a));break;case h.CONFIRM_EMAIL_FOR_BADSELLER_ACCOUNT:ia(e.requestBody).then(a=>n(a));break;case h.OPEN_PRODUCT_LINK_IN_NEW_TAB:pa(e.url).then(a=>n(a));break;case h.OPEN_LINK_WITH_AUTO_LOGIN:ga(e.url,e.utmTags).then(()=>n());break;case h.GET_AUTO_LOGIN_LINK:$n(e.url,e.utmTags).then(a=>n(a));break;case h.SUBSCRIBE_TO_PRICE_CHANGE:Ys(e.requestBody).then(a=>n(a));break;case h.UNSUBSCRIBE_FROM_PRICE_CHANGE:Xs(e.requestBody).then(a=>n(a));break;case h.GET_CITIES_LIST:Gs().then(a=>n(a));break;case h.UPDATE_USER_CITY:Qs(e.city).then(a=>n(a));break;case h.UPDATE_PRODUCT_DETAILS_ON_SELECTED_TAB:const s={type:B.UPDATE_PRODUCT_ON_CURRENT_TAB};z(t.tab.id),J(t.tab.id,s).then(a=>{n(a)});break;case h.SET_USER_DATA_ON_EACH_TAB:Mn(t.tab.id).then(a=>{n(a)});break;case h.SUBSCRIPTION_WAS_CHANGED:ba(t.tab.id,e.productId).then(()=>{n()});break;case h.SEND_ANALYTICAL_DATA:ea(e.requestBody).then(()=>n());break;case h.SEND_FEEDBACK:ta(e.requestBody).then(a=>n(a));break;case h.SUBSCRIBE_TO_WEB_PUSH_NOTIFICATIONS:Rn().then(a=>n(a));break;case h.SET_LATEST_USER_DATA:Dn().then(a=>n(a));break;case h.SEND_ERROR_MESSAGE:Zs(e.requestBody).then(()=>n());break}return!0});l.windows.onFocusChanged.addListener(async e=>{if(!e||e===-1||(await l.windows.get(e)).type!=="normal")return;const[n]=await l.tabs.query({windowId:e,active:!0}),r=n.url;if(r&&M.isSupportedUrl(r)){const o={type:B.TAB_WAS_ACTIVATED};await J(n.id,o)}});l.tabs.onActivated.addListener(async e=>{const n=(await l.tabs.get(e.tabId)).url;if(n&&M.isSupportedUrl(n)){const r={type:B.TAB_WAS_ACTIVATED};await J(e.tabId,r)}});async function pa(e){const t={active:!0,lastFocusedWindow:!0},[n]=await l.tabs.query(t);await l.tabs.create({active:!0,index:n.index+1,url:e})}async function $n(e,t){const n=new URL(`${jn}/${e}`),r=new URLSearchParams(Object.entries(t)),{authToken:o}=await I();if(o){const[i,s]=o.split(":");r.append("u",i),r.append("t",s)}for(const[i,s]of r.entries())n.searchParams.append(i,s);return n.toString()}async function ga(e,t){const n={active:!0,lastFocusedWindow:!0},r=await $n(e,t),[o]=await l.tabs.query(n);await l.tabs.create({active:!0,index:o.index+1,url:r})}async function ba(e,t){async function n(o){const i={type:B.GET_PRODUCT_ID},s=await l.tabs.sendMessage(o,i);t===s&&(z(o),await l.tabs.sendMessage(o,{type:B.SET_LAZY_LOAD}))}const r=await Bn(e);await Promise.allSettled([r.map(o=>n(o.id))])}async function Mn(e){const t={type:B.SET_USER_DATA_FROM_SESSION},n=await Bn(e);await Promise.allSettled(n.map(r=>(z(r.id),J(r.id,t))))}async function Bn(e){return(await l.tabs.query({})).filter(n=>{const r=n.url;return n.id!==e&&r&&M.isSupportedHost(r)})}async function J(e,t){try{await l.tabs.sendMessage(e,t)}catch(n){b.error(`failed to send a message => "${t.type}" to the tab with the identifier ${e}`),b.captureException(n)}}let Pn=null;async function Rn(){const{authToken:e}=await I();if(!e){b.warn("User NOT logged in, PUSH TOKEN WAS NOT UPDATED");return}b.success("Update user web push token");const t=await Ws(Pn,{vapidKey:Hn,serviceWorkerRegistration:self.registration});await fa(t)}if(xn.isPushEnabled){b.success("Push notifications enabled"),self.addEventListener("push",t=>{console.log("PUSH",t),console.log(t.data.json());const{data:n}=t.data.json();let r="";switch(n.action){case"telegramConnected":r="Телеграм успішно підключено";break;case"telegramDisconnected":r="Телеграм успішно від'єднано";break;case"emailVerified":r=`Email ${n.email} успішно підтверджено`;break}wa().then(()=>console.log("push notification has been sent")),t.waitUntil(self.registration.showNotification("Акаунт оновлено",{body:r}))});const e=Ht(Kn);Pn=as(e),self.addEventListener("activate",Rn)}else b.warn("Push notifications disabled");function ma(){const e=self.location.protocol,t=l.runtime.getManifest().version;return`${e}${t}`}async function wa(){await Dn(),await Mn()}export{ma as getClient};
