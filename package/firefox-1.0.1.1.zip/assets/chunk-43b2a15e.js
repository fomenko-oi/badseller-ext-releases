import{b as l,A as h,U as H,a as z,c as At,d as U,C as Te,g as vt,D as Qe,B as _n,S as N,e as In,f as p,h as An,i as $,j as Ze,P as vn}from"./chunk-3717627a.js";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Dt=function(e){const t=[];let n=0;for(let r=0;r<e.length;r++){let o=e.charCodeAt(r);o<128?t[n++]=o:o<2048?(t[n++]=o>>6|192,t[n++]=o&63|128):(o&64512)===55296&&r+1<e.length&&(e.charCodeAt(r+1)&64512)===56320?(o=65536+((o&1023)<<10)+(e.charCodeAt(++r)&1023),t[n++]=o>>18|240,t[n++]=o>>12&63|128,t[n++]=o>>6&63|128,t[n++]=o&63|128):(t[n++]=o>>12|224,t[n++]=o>>6&63|128,t[n++]=o&63|128)}return t},Dn=function(e){const t=[];let n=0,r=0;for(;n<e.length;){const o=e[n++];if(o<128)t[r++]=String.fromCharCode(o);else if(o>191&&o<224){const a=e[n++];t[r++]=String.fromCharCode((o&31)<<6|a&63)}else if(o>239&&o<365){const a=e[n++],s=e[n++],i=e[n++],c=((o&7)<<18|(a&63)<<12|(s&63)<<6|i&63)-65536;t[r++]=String.fromCharCode(55296+(c>>10)),t[r++]=String.fromCharCode(56320+(c&1023))}else{const a=e[n++],s=e[n++];t[r++]=String.fromCharCode((o&15)<<12|(a&63)<<6|s&63)}}return t.join("")},kn={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(e,t){if(!Array.isArray(e))throw Error("encodeByteArray takes an array as a parameter");this.init_();const n=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let o=0;o<e.length;o+=3){const a=e[o],s=o+1<e.length,i=s?e[o+1]:0,c=o+2<e.length,d=c?e[o+2]:0,u=a>>2,x=(a&3)<<4|i>>4;let J=(i&15)<<2|d>>6,Y=d&63;c||(Y=64,s||(J=64)),r.push(n[u],n[x],n[J],n[Y])}return r.join("")},encodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(e):this.encodeByteArray(Dt(e),t)},decodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(e):Dn(this.decodeStringToByteArray(e,t))},decodeStringToByteArray(e,t){this.init_();const n=t?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let o=0;o<e.length;){const a=n[e.charAt(o++)],i=o<e.length?n[e.charAt(o)]:0;++o;const d=o<e.length?n[e.charAt(o)]:64;++o;const x=o<e.length?n[e.charAt(o)]:64;if(++o,a==null||i==null||d==null||x==null)throw new Cn;const J=a<<2|i>>4;if(r.push(J),d!==64){const Y=i<<4&240|d>>2;if(r.push(Y),x!==64){const En=d<<6&192|x;r.push(En)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let e=0;e<this.ENCODED_VALS.length;e++)this.byteToCharMap_[e]=this.ENCODED_VALS.charAt(e),this.charToByteMap_[this.byteToCharMap_[e]]=e,this.byteToCharMapWebSafe_[e]=this.ENCODED_VALS_WEBSAFE.charAt(e),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]]=e,e>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)]=e,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)]=e)}}};class Cn extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const On=function(e){const t=Dt(e);return kn.encodeByteArray(t,!0)},kt=function(e){return On(e).replace(/\./g,"")};function Nn(){try{return typeof indexedDB=="object"}catch{return!1}}function $n(){return new Promise((e,t)=>{try{let n=!0;const r="validate-browser-context-for-indexeddb-analytics-module",o=self.indexedDB.open(r);o.onsuccess=()=>{o.result.close(),n||self.indexedDB.deleteDatabase(r),e(!0)},o.onupgradeneeded=()=>{n=!1},o.onerror=()=>{var a;t(((a=o.error)===null||a===void 0?void 0:a.message)||"")}}catch(n){t(n)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bn="FirebaseError";class F extends Error{constructor(t,n,r){super(n),this.code=t,this.customData=r,this.name=Bn,Object.setPrototypeOf(this,F.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,W.prototype.create)}}class W{constructor(t,n,r){this.service=t,this.serviceName=n,this.errors=r}create(t,...n){const r=n[0]||{},o=`${this.service}/${t}`,a=this.errors[t],s=a?Mn(a,r):"Error",i=`${this.serviceName}: ${s} (${o}).`;return new F(o,i,r)}}function Mn(e,t){return e.replace(Pn,(n,r)=>{const o=t[r];return o!=null?String(o):`<${r}?>`})}const Pn=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Rn(e){return e&&e._delegate?e._delegate:e}class D{constructor(t,n,r){this.name=t,this.instanceFactory=n,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(t){return this.instantiationMode=t,this}setMultipleInstances(t){return this.multipleInstances=t,this}setServiceProps(t){return this.serviceProps=t,this}setInstanceCreatedCallback(t){return this.onInstanceCreated=t,this}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var f;(function(e){e[e.DEBUG=0]="DEBUG",e[e.VERBOSE=1]="VERBOSE",e[e.INFO=2]="INFO",e[e.WARN=3]="WARN",e[e.ERROR=4]="ERROR",e[e.SILENT=5]="SILENT"})(f||(f={}));const Ln={debug:f.DEBUG,verbose:f.VERBOSE,info:f.INFO,warn:f.WARN,error:f.ERROR,silent:f.SILENT},Un=f.INFO,jn={[f.DEBUG]:"log",[f.VERBOSE]:"log",[f.INFO]:"info",[f.WARN]:"warn",[f.ERROR]:"error"},Fn=(e,t,...n)=>{if(t<e.logLevel)return;const r=new Date().toISOString(),o=jn[t];if(o)console[o](`[${r}]  ${e.name}:`,...n);else throw new Error(`Attempted to log a message with an invalid logType (value: ${t})`)};let xn=class{constructor(t){this.name=t,this._logLevel=Un,this._logHandler=Fn,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(t){if(!(t in f))throw new TypeError(`Invalid value "${t}" assigned to \`logLevel\``);this._logLevel=t}setLogLevel(t){this._logLevel=typeof t=="string"?Ln[t]:t}get logHandler(){return this._logHandler}set logHandler(t){if(typeof t!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=t}get userLogHandler(){return this._userLogHandler}set userLogHandler(t){this._userLogHandler=t}debug(...t){this._userLogHandler&&this._userLogHandler(this,f.DEBUG,...t),this._logHandler(this,f.DEBUG,...t)}log(...t){this._userLogHandler&&this._userLogHandler(this,f.VERBOSE,...t),this._logHandler(this,f.VERBOSE,...t)}info(...t){this._userLogHandler&&this._userLogHandler(this,f.INFO,...t),this._logHandler(this,f.INFO,...t)}warn(...t){this._userLogHandler&&this._userLogHandler(this,f.WARN,...t),this._logHandler(this,f.WARN,...t)}error(...t){this._userLogHandler&&this._userLogHandler(this,f.ERROR,...t),this._logHandler(this,f.ERROR,...t)}};const Hn=(e,t)=>t.some(n=>e instanceof n);let et,tt;function Kn(){return et||(et=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Vn(){return tt||(tt=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Ct=new WeakMap,Ee=new WeakMap,Ot=new WeakMap,re=new WeakMap,$e=new WeakMap;function Wn(e){const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("success",a),e.removeEventListener("error",s)},a=()=>{n(I(e.result)),o()},s=()=>{r(e.error),o()};e.addEventListener("success",a),e.addEventListener("error",s)});return t.then(n=>{n instanceof IDBCursor&&Ct.set(n,e)}).catch(()=>{}),$e.set(t,e),t}function qn(e){if(Ee.has(e))return;const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("complete",a),e.removeEventListener("error",s),e.removeEventListener("abort",s)},a=()=>{n(),o()},s=()=>{r(e.error||new DOMException("AbortError","AbortError")),o()};e.addEventListener("complete",a),e.addEventListener("error",s),e.addEventListener("abort",s)});Ee.set(e,t)}let _e={get(e,t,n){if(e instanceof IDBTransaction){if(t==="done")return Ee.get(e);if(t==="objectStoreNames")return e.objectStoreNames||Ot.get(e);if(t==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return I(e[t])},set(e,t,n){return e[t]=n,!0},has(e,t){return e instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in e}};function Gn(e){_e=e(_e)}function Jn(e){return e===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(t,...n){const r=e.call(oe(this),t,...n);return Ot.set(r,t.sort?t.sort():[t]),I(r)}:Vn().includes(e)?function(...t){return e.apply(oe(this),t),I(Ct.get(this))}:function(...t){return I(e.apply(oe(this),t))}}function Yn(e){return typeof e=="function"?Jn(e):(e instanceof IDBTransaction&&qn(e),Hn(e,Kn())?new Proxy(e,_e):e)}function I(e){if(e instanceof IDBRequest)return Wn(e);if(re.has(e))return re.get(e);const t=Yn(e);return t!==e&&(re.set(e,t),$e.set(t,e)),t}const oe=e=>$e.get(e);function zn(e,t,{blocked:n,upgrade:r,blocking:o,terminated:a}={}){const s=indexedDB.open(e,t),i=I(s);return r&&s.addEventListener("upgradeneeded",c=>{r(I(s.result),c.oldVersion,c.newVersion,I(s.transaction),c)}),n&&s.addEventListener("blocked",c=>n(c.oldVersion,c.newVersion,c)),i.then(c=>{a&&c.addEventListener("close",()=>a()),o&&c.addEventListener("versionchange",d=>o(d.oldVersion,d.newVersion,d))}).catch(()=>{}),i}const Xn=["get","getKey","getAll","getAllKeys","count"],Qn=["put","add","delete","clear"],ae=new Map;function nt(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&typeof t=="string"))return;if(ae.get(t))return ae.get(t);const n=t.replace(/FromIndex$/,""),r=t!==n,o=Qn.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(o||Xn.includes(n)))return;const a=async function(s,...i){const c=this.transaction(s,o?"readwrite":"readonly");let d=c.store;return r&&(d=d.index(i.shift())),(await Promise.all([d[n](...i),o&&c.done]))[0]};return ae.set(t,a),a}Gn(e=>({...e,get:(t,n,r)=>nt(t,n)||e.get(t,n,r),has:(t,n)=>!!nt(t,n)||e.has(t,n)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zn{constructor(t){this.container=t}getPlatformInfoString(){return this.container.getProviders().map(n=>{if(er(n)){const r=n.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(n=>n).join(" ")}}function er(e){const t=e.getComponent();return(t==null?void 0:t.type)==="VERSION"}const Ie="@firebase/app",rt="0.9.13";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const B=new xn("@firebase/app"),tr="@firebase/app-compat",nr="@firebase/analytics-compat",rr="@firebase/analytics",or="@firebase/app-check-compat",ar="@firebase/app-check",sr="@firebase/auth",ir="@firebase/auth-compat",cr="@firebase/database",ur="@firebase/database-compat",dr="@firebase/functions",lr="@firebase/functions-compat",fr="@firebase/installations",pr="@firebase/installations-compat",hr="@firebase/messaging",gr="@firebase/messaging-compat",br="@firebase/performance",wr="@firebase/performance-compat",mr="@firebase/remote-config",yr="@firebase/remote-config-compat",Sr="@firebase/storage",Tr="@firebase/storage-compat",Er="@firebase/firestore",_r="@firebase/firestore-compat",Ir="firebase",Ar={[Ie]:"fire-core",[tr]:"fire-core-compat",[rr]:"fire-analytics",[nr]:"fire-analytics-compat",[ar]:"fire-app-check",[or]:"fire-app-check-compat",[sr]:"fire-auth",[ir]:"fire-auth-compat",[cr]:"fire-rtdb",[ur]:"fire-rtdb-compat",[dr]:"fire-fn",[lr]:"fire-fn-compat",[fr]:"fire-iid",[pr]:"fire-iid-compat",[hr]:"fire-fcm",[gr]:"fire-fcm-compat",[br]:"fire-perf",[wr]:"fire-perf-compat",[mr]:"fire-rc",[yr]:"fire-rc-compat",[Sr]:"fire-gcs",[Tr]:"fire-gcs-compat",[Er]:"fire-fst",[_r]:"fire-fst-compat","fire-js":"fire-js",[Ir]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vr=new Map,ot=new Map;function Dr(e,t){try{e.container.addComponent(t)}catch(n){B.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`,n)}}function k(e){const t=e.name;if(ot.has(t))return B.debug(`There were multiple attempts to register component ${t}.`),!1;ot.set(t,e);for(const n of vr.values())Dr(n,e);return!0}function Nt(e,t){const n=e.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),e.container.getProvider(t)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kr={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}."},Be=new W("app","Firebase",kr);function A(e,t,n){var r;let o=(r=Ar[e])!==null&&r!==void 0?r:e;n&&(o+=`-${n}`);const a=o.match(/\s|\//),s=t.match(/\s|\//);if(a||s){const i=[`Unable to register library "${o}" with version "${t}":`];a&&i.push(`library name "${o}" contains illegal characters (whitespace or "/")`),a&&s&&i.push("and"),s&&i.push(`version name "${t}" contains illegal characters (whitespace or "/")`),B.warn(i.join(" "));return}k(new D(`${o}-version`,()=>({library:o,version:t}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cr="firebase-heartbeat-database",Or=1,K="firebase-heartbeat-store";let se=null;function $t(){return se||(se=zn(Cr,Or,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(K)}}}).catch(e=>{throw Be.create("idb-open",{originalErrorMessage:e.message})})),se}async function Nr(e){try{return await(await $t()).transaction(K).objectStore(K).get(Bt(e))}catch(t){if(t instanceof F)B.warn(t.message);else{const n=Be.create("idb-get",{originalErrorMessage:t==null?void 0:t.message});B.warn(n.message)}}}async function at(e,t){try{const r=(await $t()).transaction(K,"readwrite");await r.objectStore(K).put(t,Bt(e)),await r.done}catch(n){if(n instanceof F)B.warn(n.message);else{const r=Be.create("idb-set",{originalErrorMessage:n==null?void 0:n.message});B.warn(r.message)}}}function Bt(e){return`${e.name}!${e.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $r=1024,Br=30*24*60*60*1e3;class Mr{constructor(t){this.container=t,this._heartbeatsCache=null;const n=this.container.getProvider("app").getImmediate();this._storage=new Rr(n),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){const n=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),r=st();if(this._heartbeatsCache===null&&(this._heartbeatsCache=await this._heartbeatsCachePromise),!(this._heartbeatsCache.lastSentHeartbeatDate===r||this._heartbeatsCache.heartbeats.some(o=>o.date===r)))return this._heartbeatsCache.heartbeats.push({date:r,agent:n}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(o=>{const a=new Date(o.date).valueOf();return Date.now()-a<=Br}),this._storage.overwrite(this._heartbeatsCache)}async getHeartbeatsHeader(){if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,this._heartbeatsCache===null||this._heartbeatsCache.heartbeats.length===0)return"";const t=st(),{heartbeatsToSend:n,unsentEntries:r}=Pr(this._heartbeatsCache.heartbeats),o=kt(JSON.stringify({version:2,heartbeats:n}));return this._heartbeatsCache.lastSentHeartbeatDate=t,r.length>0?(this._heartbeatsCache.heartbeats=r,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),o}}function st(){return new Date().toISOString().substring(0,10)}function Pr(e,t=$r){const n=[];let r=e.slice();for(const o of e){const a=n.find(s=>s.agent===o.agent);if(a){if(a.dates.push(o.date),it(n)>t){a.dates.pop();break}}else if(n.push({agent:o.agent,dates:[o.date]}),it(n)>t){n.pop();break}r=r.slice(1)}return{heartbeatsToSend:n,unsentEntries:r}}class Rr{constructor(t){this.app=t,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Nn()?$n().then(()=>!0).catch(()=>!1):!1}async read(){return await this._canUseIndexedDBPromise?await Nr(this.app)||{heartbeats:[]}:{heartbeats:[]}}async overwrite(t){var n;if(await this._canUseIndexedDBPromise){const o=await this.read();return at(this.app,{lastSentHeartbeatDate:(n=t.lastSentHeartbeatDate)!==null&&n!==void 0?n:o.lastSentHeartbeatDate,heartbeats:t.heartbeats})}else return}async add(t){var n;if(await this._canUseIndexedDBPromise){const o=await this.read();return at(this.app,{lastSentHeartbeatDate:(n=t.lastSentHeartbeatDate)!==null&&n!==void 0?n:o.lastSentHeartbeatDate,heartbeats:[...o.heartbeats,...t.heartbeats]})}else return}}function it(e){return kt(JSON.stringify({version:2,heartbeats:e})).length}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Lr(e){k(new D("platform-logger",t=>new Zn(t),"PRIVATE")),k(new D("heartbeat",t=>new Mr(t),"PRIVATE")),A(Ie,rt,e),A(Ie,rt,"esm2017"),A("fire-js","")}Lr("");var Ur="firebase",jr="9.23.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */A(Ur,jr,"app");const Fr=(e,t)=>t.some(n=>e instanceof n);let ct,ut;function xr(){return ct||(ct=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Hr(){return ut||(ut=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Mt=new WeakMap,Ae=new WeakMap,Pt=new WeakMap,ie=new WeakMap,Me=new WeakMap;function Kr(e){const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("success",a),e.removeEventListener("error",s)},a=()=>{n(v(e.result)),o()},s=()=>{r(e.error),o()};e.addEventListener("success",a),e.addEventListener("error",s)});return t.then(n=>{n instanceof IDBCursor&&Mt.set(n,e)}).catch(()=>{}),Me.set(t,e),t}function Vr(e){if(Ae.has(e))return;const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("complete",a),e.removeEventListener("error",s),e.removeEventListener("abort",s)},a=()=>{n(),o()},s=()=>{r(e.error||new DOMException("AbortError","AbortError")),o()};e.addEventListener("complete",a),e.addEventListener("error",s),e.addEventListener("abort",s)});Ae.set(e,t)}let ve={get(e,t,n){if(e instanceof IDBTransaction){if(t==="done")return Ae.get(e);if(t==="objectStoreNames")return e.objectStoreNames||Pt.get(e);if(t==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return v(e[t])},set(e,t,n){return e[t]=n,!0},has(e,t){return e instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in e}};function Wr(e){ve=e(ve)}function qr(e){return e===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(t,...n){const r=e.call(ce(this),t,...n);return Pt.set(r,t.sort?t.sort():[t]),v(r)}:Hr().includes(e)?function(...t){return e.apply(ce(this),t),v(Mt.get(this))}:function(...t){return v(e.apply(ce(this),t))}}function Gr(e){return typeof e=="function"?qr(e):(e instanceof IDBTransaction&&Vr(e),Fr(e,xr())?new Proxy(e,ve):e)}function v(e){if(e instanceof IDBRequest)return Kr(e);if(ie.has(e))return ie.get(e);const t=Gr(e);return t!==e&&(ie.set(e,t),Me.set(t,e)),t}const ce=e=>Me.get(e);function Jr(e,t,{blocked:n,upgrade:r,blocking:o,terminated:a}={}){const s=indexedDB.open(e,t),i=v(s);return r&&s.addEventListener("upgradeneeded",c=>{r(v(s.result),c.oldVersion,c.newVersion,v(s.transaction))}),n&&s.addEventListener("blocked",()=>n()),i.then(c=>{a&&c.addEventListener("close",()=>a()),o&&c.addEventListener("versionchange",()=>o())}).catch(()=>{}),i}const Yr=["get","getKey","getAll","getAllKeys","count"],zr=["put","add","delete","clear"],ue=new Map;function dt(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&typeof t=="string"))return;if(ue.get(t))return ue.get(t);const n=t.replace(/FromIndex$/,""),r=t!==n,o=zr.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(o||Yr.includes(n)))return;const a=async function(s,...i){const c=this.transaction(s,o?"readwrite":"readonly");let d=c.store;return r&&(d=d.index(i.shift())),(await Promise.all([d[n](...i),o&&c.done]))[0]};return ue.set(t,a),a}Wr(e=>({...e,get:(t,n,r)=>dt(t,n)||e.get(t,n,r),has:(t,n)=>!!dt(t,n)||e.has(t,n)}));const Rt="@firebase/installations",Pe="0.6.4";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Lt=1e4,Ut=`w:${Pe}`,jt="FIS_v2",Xr="https://firebaseinstallations.googleapis.com/v1",Qr=60*60*1e3,Zr="installations",eo="Installations";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const to={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."},M=new W(Zr,eo,to);function Ft(e){return e instanceof F&&e.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xt({projectId:e}){return`${Xr}/projects/${e}/installations`}function Ht(e){return{token:e.token,requestStatus:2,expiresIn:ro(e.expiresIn),creationTime:Date.now()}}async function Kt(e,t){const r=(await t.json()).error;return M.create("request-failed",{requestName:e,serverCode:r.code,serverMessage:r.message,serverStatus:r.status})}function Vt({apiKey:e}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e})}function no(e,{refreshToken:t}){const n=Vt(e);return n.append("Authorization",oo(t)),n}async function Wt(e){const t=await e();return t.status>=500&&t.status<600?e():t}function ro(e){return Number(e.replace("s","000"))}function oo(e){return`${jt} ${e}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ao({appConfig:e,heartbeatServiceProvider:t},{fid:n}){const r=xt(e),o=Vt(e),a=t.getImmediate({optional:!0});if(a){const d=await a.getHeartbeatsHeader();d&&o.append("x-firebase-client",d)}const s={fid:n,authVersion:jt,appId:e.appId,sdkVersion:Ut},i={method:"POST",headers:o,body:JSON.stringify(s)},c=await Wt(()=>fetch(r,i));if(c.ok){const d=await c.json();return{fid:d.fid||n,registrationStatus:2,refreshToken:d.refreshToken,authToken:Ht(d.authToken)}}else throw await Kt("Create Installation",c)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qt(e){return new Promise(t=>{setTimeout(t,e)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function so(e){return btoa(String.fromCharCode(...e)).replace(/\+/g,"-").replace(/\//g,"_")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const io=/^[cdef][\w-]{21}$/,De="";function co(){try{const e=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(e),e[0]=112+e[0]%16;const n=uo(e);return io.test(n)?n:De}catch{return De}}function uo(e){return so(e).substr(0,22)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ee(e){return`${e.appName}!${e.appId}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gt=new Map;function Jt(e,t){const n=ee(e);Yt(n,t),lo(n,t)}function Yt(e,t){const n=Gt.get(e);if(n)for(const r of n)r(t)}function lo(e,t){const n=fo();n&&n.postMessage({key:e,fid:t}),po()}let O=null;function fo(){return!O&&"BroadcastChannel"in self&&(O=new BroadcastChannel("[Firebase] FID Change"),O.onmessage=e=>{Yt(e.data.key,e.data.fid)}),O}function po(){Gt.size===0&&O&&(O.close(),O=null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ho="firebase-installations-database",go=1,P="firebase-installations-store";let de=null;function Re(){return de||(de=Jr(ho,go,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(P)}}})),de}async function X(e,t){const n=ee(e),o=(await Re()).transaction(P,"readwrite"),a=o.objectStore(P),s=await a.get(n);return await a.put(t,n),await o.done,(!s||s.fid!==t.fid)&&Jt(e,t.fid),t}async function zt(e){const t=ee(e),r=(await Re()).transaction(P,"readwrite");await r.objectStore(P).delete(t),await r.done}async function te(e,t){const n=ee(e),o=(await Re()).transaction(P,"readwrite"),a=o.objectStore(P),s=await a.get(n),i=t(s);return i===void 0?await a.delete(n):await a.put(i,n),await o.done,i&&(!s||s.fid!==i.fid)&&Jt(e,i.fid),i}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Le(e){let t;const n=await te(e.appConfig,r=>{const o=bo(r),a=wo(e,o);return t=a.registrationPromise,a.installationEntry});return n.fid===De?{installationEntry:await t}:{installationEntry:n,registrationPromise:t}}function bo(e){const t=e||{fid:co(),registrationStatus:0};return Xt(t)}function wo(e,t){if(t.registrationStatus===0){if(!navigator.onLine){const o=Promise.reject(M.create("app-offline"));return{installationEntry:t,registrationPromise:o}}const n={fid:t.fid,registrationStatus:1,registrationTime:Date.now()},r=mo(e,n);return{installationEntry:n,registrationPromise:r}}else return t.registrationStatus===1?{installationEntry:t,registrationPromise:yo(e)}:{installationEntry:t}}async function mo(e,t){try{const n=await ao(e,t);return X(e.appConfig,n)}catch(n){throw Ft(n)&&n.customData.serverCode===409?await zt(e.appConfig):await X(e.appConfig,{fid:t.fid,registrationStatus:0}),n}}async function yo(e){let t=await lt(e.appConfig);for(;t.registrationStatus===1;)await qt(100),t=await lt(e.appConfig);if(t.registrationStatus===0){const{installationEntry:n,registrationPromise:r}=await Le(e);return r||n}return t}function lt(e){return te(e,t=>{if(!t)throw M.create("installation-not-found");return Xt(t)})}function Xt(e){return So(e)?{fid:e.fid,registrationStatus:0}:e}function So(e){return e.registrationStatus===1&&e.registrationTime+Lt<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function To({appConfig:e,heartbeatServiceProvider:t},n){const r=Eo(e,n),o=no(e,n),a=t.getImmediate({optional:!0});if(a){const d=await a.getHeartbeatsHeader();d&&o.append("x-firebase-client",d)}const s={installation:{sdkVersion:Ut,appId:e.appId}},i={method:"POST",headers:o,body:JSON.stringify(s)},c=await Wt(()=>fetch(r,i));if(c.ok){const d=await c.json();return Ht(d)}else throw await Kt("Generate Auth Token",c)}function Eo(e,{fid:t}){return`${xt(e)}/${t}/authTokens:generate`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ue(e,t=!1){let n;const r=await te(e.appConfig,a=>{if(!Qt(a))throw M.create("not-registered");const s=a.authToken;if(!t&&Ao(s))return a;if(s.requestStatus===1)return n=_o(e,t),a;{if(!navigator.onLine)throw M.create("app-offline");const i=Do(a);return n=Io(e,i),i}});return n?await n:r.authToken}async function _o(e,t){let n=await ft(e.appConfig);for(;n.authToken.requestStatus===1;)await qt(100),n=await ft(e.appConfig);const r=n.authToken;return r.requestStatus===0?Ue(e,t):r}function ft(e){return te(e,t=>{if(!Qt(t))throw M.create("not-registered");const n=t.authToken;return ko(n)?Object.assign(Object.assign({},t),{authToken:{requestStatus:0}}):t})}async function Io(e,t){try{const n=await To(e,t),r=Object.assign(Object.assign({},t),{authToken:n});return await X(e.appConfig,r),n}catch(n){if(Ft(n)&&(n.customData.serverCode===401||n.customData.serverCode===404))await zt(e.appConfig);else{const r=Object.assign(Object.assign({},t),{authToken:{requestStatus:0}});await X(e.appConfig,r)}throw n}}function Qt(e){return e!==void 0&&e.registrationStatus===2}function Ao(e){return e.requestStatus===2&&!vo(e)}function vo(e){const t=Date.now();return t<e.creationTime||e.creationTime+e.expiresIn<t+Qr}function Do(e){const t={requestStatus:1,requestTime:Date.now()};return Object.assign(Object.assign({},e),{authToken:t})}function ko(e){return e.requestStatus===1&&e.requestTime+Lt<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Co(e){const t=e,{installationEntry:n,registrationPromise:r}=await Le(t);return r?r.catch(console.error):Ue(t).catch(console.error),n.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Oo(e,t=!1){const n=e;return await No(n),(await Ue(n,t)).token}async function No(e){const{registrationPromise:t}=await Le(e);t&&await t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $o(e){if(!e||!e.options)throw le("App Configuration");if(!e.name)throw le("App Name");const t=["projectId","apiKey","appId"];for(const n of t)if(!e.options[n])throw le(n);return{appName:e.name,projectId:e.options.projectId,apiKey:e.options.apiKey,appId:e.options.appId}}function le(e){return M.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Zt="installations",Bo="installations-internal",Mo=e=>{const t=e.getProvider("app").getImmediate(),n=$o(t),r=Nt(t,"heartbeat");return{app:t,appConfig:n,heartbeatServiceProvider:r,_delete:()=>Promise.resolve()}},Po=e=>{const t=e.getProvider("app").getImmediate(),n=Nt(t,Zt).getImmediate();return{getId:()=>Co(n),getToken:o=>Oo(n,o)}};function Ro(){k(new D(Zt,Mo,"PUBLIC")),k(new D(Bo,Po,"PRIVATE"))}Ro();A(Rt,Pe);A(Rt,Pe,"esm2017");const Lo=(e,t)=>t.some(n=>e instanceof n);let pt,ht;function Uo(){return pt||(pt=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function jo(){return ht||(ht=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const en=new WeakMap,ke=new WeakMap,tn=new WeakMap,fe=new WeakMap,je=new WeakMap;function Fo(e){const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("success",a),e.removeEventListener("error",s)},a=()=>{n(S(e.result)),o()},s=()=>{r(e.error),o()};e.addEventListener("success",a),e.addEventListener("error",s)});return t.then(n=>{n instanceof IDBCursor&&en.set(n,e)}).catch(()=>{}),je.set(t,e),t}function xo(e){if(ke.has(e))return;const t=new Promise((n,r)=>{const o=()=>{e.removeEventListener("complete",a),e.removeEventListener("error",s),e.removeEventListener("abort",s)},a=()=>{n(),o()},s=()=>{r(e.error||new DOMException("AbortError","AbortError")),o()};e.addEventListener("complete",a),e.addEventListener("error",s),e.addEventListener("abort",s)});ke.set(e,t)}let Ce={get(e,t,n){if(e instanceof IDBTransaction){if(t==="done")return ke.get(e);if(t==="objectStoreNames")return e.objectStoreNames||tn.get(e);if(t==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return S(e[t])},set(e,t,n){return e[t]=n,!0},has(e,t){return e instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in e}};function Ho(e){Ce=e(Ce)}function Ko(e){return e===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(t,...n){const r=e.call(pe(this),t,...n);return tn.set(r,t.sort?t.sort():[t]),S(r)}:jo().includes(e)?function(...t){return e.apply(pe(this),t),S(en.get(this))}:function(...t){return S(e.apply(pe(this),t))}}function Vo(e){return typeof e=="function"?Ko(e):(e instanceof IDBTransaction&&xo(e),Lo(e,Uo())?new Proxy(e,Ce):e)}function S(e){if(e instanceof IDBRequest)return Fo(e);if(fe.has(e))return fe.get(e);const t=Vo(e);return t!==e&&(fe.set(e,t),je.set(t,e)),t}const pe=e=>je.get(e);function ne(e,t,{blocked:n,upgrade:r,blocking:o,terminated:a}={}){const s=indexedDB.open(e,t),i=S(s);return r&&s.addEventListener("upgradeneeded",c=>{r(S(s.result),c.oldVersion,c.newVersion,S(s.transaction))}),n&&s.addEventListener("blocked",()=>n()),i.then(c=>{a&&c.addEventListener("close",()=>a()),o&&c.addEventListener("versionchange",()=>o())}).catch(()=>{}),i}function j(e,{blocked:t}={}){const n=indexedDB.deleteDatabase(e);return t&&n.addEventListener("blocked",()=>t()),S(n).then(()=>{})}const Wo=["get","getKey","getAll","getAllKeys","count"],qo=["put","add","delete","clear"],he=new Map;function gt(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&typeof t=="string"))return;if(he.get(t))return he.get(t);const n=t.replace(/FromIndex$/,""),r=t!==n,o=qo.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(o||Wo.includes(n)))return;const a=async function(s,...i){const c=this.transaction(s,o?"readwrite":"readonly");let d=c.store;return r&&(d=d.index(i.shift())),(await Promise.all([d[n](...i),o&&c.done]))[0]};return he.set(t,a),a}Ho(e=>({...e,get:(t,n,r)=>gt(t,n)||e.get(t,n,r),has:(t,n)=>!!gt(t,n)||e.has(t,n)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nn="BDOU99-h67HcA6JeFXHbSNMu7e2yNNu3RzoMj8TM4W88jITfq7ZmPvIM1Iv-4_l2LxQcYwhqby2xGpWwzjfAnG4",Go="https://fcmregistrations.googleapis.com/v1",rn="FCM_MSG",Jo="google.c.a.c_id",Yo=3,zo=1;var Q;(function(e){e[e.DATA_MESSAGE=1]="DATA_MESSAGE",e[e.DISPLAY_NOTIFICATION=3]="DISPLAY_NOTIFICATION"})(Q||(Q={}));/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */var Z;(function(e){e.PUSH_RECEIVED="push-received",e.NOTIFICATION_CLICKED="notification-clicked"})(Z||(Z={}));/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function m(e){const t=new Uint8Array(e);return btoa(String.fromCharCode(...t)).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_")}function Xo(e){const t="=".repeat((4-e.length%4)%4),n=(e+t).replace(/\-/g,"+").replace(/_/g,"/"),r=atob(n),o=new Uint8Array(r.length);for(let a=0;a<r.length;++a)o[a]=r.charCodeAt(a);return o}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ge="fcm_token_details_db",Qo=5,bt="fcm_token_object_Store";async function Zo(e){if("databases"in indexedDB&&!(await indexedDB.databases()).map(a=>a.name).includes(ge))return null;let t=null;return(await ne(ge,Qo,{upgrade:async(r,o,a,s)=>{var i;if(o<2||!r.objectStoreNames.contains(bt))return;const c=s.objectStore(bt),d=await c.index("fcmSenderId").get(e);if(await c.clear(),!!d){if(o===2){const u=d;if(!u.auth||!u.p256dh||!u.endpoint)return;t={token:u.fcmToken,createTime:(i=u.createTime)!==null&&i!==void 0?i:Date.now(),subscriptionOptions:{auth:u.auth,p256dh:u.p256dh,endpoint:u.endpoint,swScope:u.swScope,vapidKey:typeof u.vapidKey=="string"?u.vapidKey:m(u.vapidKey)}}}else if(o===3){const u=d;t={token:u.fcmToken,createTime:u.createTime,subscriptionOptions:{auth:m(u.auth),p256dh:m(u.p256dh),endpoint:u.endpoint,swScope:u.swScope,vapidKey:m(u.vapidKey)}}}else if(o===4){const u=d;t={token:u.fcmToken,createTime:u.createTime,subscriptionOptions:{auth:m(u.auth),p256dh:m(u.p256dh),endpoint:u.endpoint,swScope:u.swScope,vapidKey:m(u.vapidKey)}}}}}})).close(),await j(ge),await j("fcm_vapid_details_db"),await j("undefined"),ea(t)?t:null}function ea(e){if(!e||!e.subscriptionOptions)return!1;const{subscriptionOptions:t}=e;return typeof e.createTime=="number"&&e.createTime>0&&typeof e.token=="string"&&e.token.length>0&&typeof t.auth=="string"&&t.auth.length>0&&typeof t.p256dh=="string"&&t.p256dh.length>0&&typeof t.endpoint=="string"&&t.endpoint.length>0&&typeof t.swScope=="string"&&t.swScope.length>0&&typeof t.vapidKey=="string"&&t.vapidKey.length>0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ta="firebase-messaging-database",na=1,R="firebase-messaging-store";let be=null;function Fe(){return be||(be=ne(ta,na,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(R)}}})),be}async function xe(e){const t=Ke(e),r=await(await Fe()).transaction(R).objectStore(R).get(t);if(r)return r;{const o=await Zo(e.appConfig.senderId);if(o)return await He(e,o),o}}async function He(e,t){const n=Ke(e),o=(await Fe()).transaction(R,"readwrite");return await o.objectStore(R).put(t,n),await o.done,t}async function ra(e){const t=Ke(e),r=(await Fe()).transaction(R,"readwrite");await r.objectStore(R).delete(t),await r.done}function Ke({appConfig:e}){return e.appId}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oa={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"only-available-in-window":"This method is available in a Window context.","only-available-in-sw":"This method is available in a service worker context.","permission-default":"The notification permission was not granted and dismissed instead.","permission-blocked":"The notification permission was not granted and blocked instead.","unsupported-browser":"This browser doesn't support the API's required to use the Firebase SDK.","indexed-db-unsupported":"This browser doesn't support indexedDb.open() (ex. Safari iFrame, Firefox Private Browsing, etc)","failed-service-worker-registration":"We are unable to register the default service worker. {$browserErrorMessage}","token-subscribe-failed":"A problem occurred while subscribing the user to FCM: {$errorInfo}","token-subscribe-no-token":"FCM returned no token when subscribing the user to push.","token-unsubscribe-failed":"A problem occurred while unsubscribing the user from FCM: {$errorInfo}","token-update-failed":"A problem occurred while updating the user from FCM: {$errorInfo}","token-update-no-token":"FCM returned no token when updating the user to push.","use-sw-after-get-token":"The useServiceWorker() method may only be called once and must be called before calling getToken() to ensure your service worker is used.","invalid-sw-registration":"The input to useServiceWorker() must be a ServiceWorkerRegistration.","invalid-bg-handler":"The input to setBackgroundMessageHandler() must be a function.","invalid-vapid-key":"The public VAPID key must be a string.","use-vapid-key-after-get-token":"The usePublicVapidKey() method may only be called once and must be called before calling getToken() to ensure your VAPID key is used."},T=new W("messaging","Messaging",oa);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function aa(e,t){const n=await We(e),r=an(t),o={method:"POST",headers:n,body:JSON.stringify(r)};let a;try{a=await(await fetch(Ve(e.appConfig),o)).json()}catch(s){throw T.create("token-subscribe-failed",{errorInfo:s==null?void 0:s.toString()})}if(a.error){const s=a.error.message;throw T.create("token-subscribe-failed",{errorInfo:s})}if(!a.token)throw T.create("token-subscribe-no-token");return a.token}async function sa(e,t){const n=await We(e),r=an(t.subscriptionOptions),o={method:"PATCH",headers:n,body:JSON.stringify(r)};let a;try{a=await(await fetch(`${Ve(e.appConfig)}/${t.token}`,o)).json()}catch(s){throw T.create("token-update-failed",{errorInfo:s==null?void 0:s.toString()})}if(a.error){const s=a.error.message;throw T.create("token-update-failed",{errorInfo:s})}if(!a.token)throw T.create("token-update-no-token");return a.token}async function on(e,t){const r={method:"DELETE",headers:await We(e)};try{const a=await(await fetch(`${Ve(e.appConfig)}/${t}`,r)).json();if(a.error){const s=a.error.message;throw T.create("token-unsubscribe-failed",{errorInfo:s})}}catch(o){throw T.create("token-unsubscribe-failed",{errorInfo:o==null?void 0:o.toString()})}}function Ve({projectId:e}){return`${Go}/projects/${e}/registrations`}async function We({appConfig:e,installations:t}){const n=await t.getToken();return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e.apiKey,"x-goog-firebase-installations-auth":`FIS ${n}`})}function an({p256dh:e,auth:t,endpoint:n,vapidKey:r}){const o={web:{endpoint:n,auth:t,p256dh:e}};return r!==nn&&(o.web.applicationPubKey=r),o}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ia=7*24*60*60*1e3;async function ca(e){const t=await da(e.swRegistration,e.vapidKey),n={vapidKey:e.vapidKey,swScope:e.swRegistration.scope,endpoint:t.endpoint,auth:m(t.getKey("auth")),p256dh:m(t.getKey("p256dh"))},r=await xe(e.firebaseDependencies);if(r){if(la(r.subscriptionOptions,n))return Date.now()>=r.createTime+ia?ua(e,{token:r.token,createTime:Date.now(),subscriptionOptions:n}):r.token;try{await on(e.firebaseDependencies,r.token)}catch(o){console.warn(o)}return wt(e.firebaseDependencies,n)}else return wt(e.firebaseDependencies,n)}async function Oe(e){const t=await xe(e.firebaseDependencies);t&&(await on(e.firebaseDependencies,t.token),await ra(e.firebaseDependencies));const n=await e.swRegistration.pushManager.getSubscription();return n?n.unsubscribe():!0}async function ua(e,t){try{const n=await sa(e.firebaseDependencies,t),r=Object.assign(Object.assign({},t),{token:n,createTime:Date.now()});return await He(e.firebaseDependencies,r),n}catch(n){throw await Oe(e),n}}async function wt(e,t){const r={token:await aa(e,t),createTime:Date.now(),subscriptionOptions:t};return await He(e,r),r.token}async function da(e,t){const n=await e.pushManager.getSubscription();return n||e.pushManager.subscribe({userVisibleOnly:!0,applicationServerKey:Xo(t)})}function la(e,t){const n=t.vapidKey===e.vapidKey,r=t.endpoint===e.endpoint,o=t.auth===e.auth,a=t.p256dh===e.p256dh;return n&&r&&o&&a}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fa(e){const t={from:e.from,collapseKey:e.collapse_key,messageId:e.fcmMessageId};return pa(t,e),ha(t,e),ga(t,e),t}function pa(e,t){if(!t.notification)return;e.notification={};const n=t.notification.title;n&&(e.notification.title=n);const r=t.notification.body;r&&(e.notification.body=r);const o=t.notification.image;o&&(e.notification.image=o);const a=t.notification.icon;a&&(e.notification.icon=a)}function ha(e,t){t.data&&(e.data=t.data)}function ga(e,t){var n,r,o,a,s;if(!t.fcmOptions&&!(!((n=t.notification)===null||n===void 0)&&n.click_action))return;e.fcmOptions={};const i=(o=(r=t.fcmOptions)===null||r===void 0?void 0:r.link)!==null&&o!==void 0?o:(a=t.notification)===null||a===void 0?void 0:a.click_action;i&&(e.fcmOptions.link=i);const c=(s=t.fcmOptions)===null||s===void 0?void 0:s.analytics_label;c&&(e.fcmOptions.analyticsLabel=c)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ba(e){return typeof e=="object"&&!!e&&Jo in e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wa(e){return new Promise(t=>{setTimeout(t,e)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */sn("hts/frbslgigp.ogepscmv/ieo/eaylg","tp:/ieaeogn-agolai.o/1frlglgc/o");sn("AzSCbw63g1R0nCw85jG8","Iaya3yLKwmgvh7cF0q4");async function ma(e,t){const n=ya(t,await e.firebaseDependencies.installations.getId());Sa(e,n)}function ya(e,t){var n,r;const o={};return e.from&&(o.project_number=e.from),e.fcmMessageId&&(o.message_id=e.fcmMessageId),o.instance_id=t,e.notification?o.message_type=Q.DISPLAY_NOTIFICATION.toString():o.message_type=Q.DATA_MESSAGE.toString(),o.sdk_platform=Yo.toString(),o.package_name=self.origin.replace(/(^\w+:|^)\/\//,""),e.collapse_key&&(o.collapse_key=e.collapse_key),o.event=zo.toString(),!((n=e.fcmOptions)===null||n===void 0)&&n.analytics_label&&(o.analytics_label=(r=e.fcmOptions)===null||r===void 0?void 0:r.analytics_label),o}function Sa(e,t){const n={};n.event_time_ms=Math.floor(Date.now()).toString(),n.source_extension_json_proto3=JSON.stringify(t),e.logEvents.push(n)}function sn(e,t){const n=[];for(let r=0;r<e.length;r++)n.push(e.charAt(r)),r<t.length&&n.push(t.charAt(r));return n.join("")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ta(e,t){var n,r;const{newSubscription:o}=e;if(!o){await Oe(t);return}const a=await xe(t.firebaseDependencies);await Oe(t),t.vapidKey=(r=(n=a==null?void 0:a.subscriptionOptions)===null||n===void 0?void 0:n.vapidKey)!==null&&r!==void 0?r:nn,await ca(t)}async function Ea(e,t){const n=Aa(e);if(!n)return;t.deliveryMetricsExportedToBigQueryEnabled&&await ma(t,n);const r=await cn();if(Da(r))return ka(r,n);if(n.notification&&await Ca(Ia(n)),!!t&&t.onBackgroundMessageHandler){const o=fa(n);typeof t.onBackgroundMessageHandler=="function"?await t.onBackgroundMessageHandler(o):t.onBackgroundMessageHandler.next(o)}}async function _a(e){var t,n;const r=(n=(t=e.notification)===null||t===void 0?void 0:t.data)===null||n===void 0?void 0:n[rn];if(r){if(e.action)return}else return;e.stopImmediatePropagation(),e.notification.close();const o=Oa(r);if(!o)return;const a=new URL(o,self.location.href),s=new URL(self.location.origin);if(a.host!==s.host)return;let i=await va(a);if(i?i=await i.focus():(i=await self.clients.openWindow(o),await wa(3e3)),!!i)return r.messageType=Z.NOTIFICATION_CLICKED,r.isFirebaseMessaging=!0,i.postMessage(r)}function Ia(e){const t=Object.assign({},e.notification);return t.data={[rn]:e},t}function Aa({data:e}){if(!e)return null;try{return e.json()}catch{return null}}async function va(e){const t=await cn();for(const n of t){const r=new URL(n.url,self.location.href);if(e.host===r.host)return n}return null}function Da(e){return e.some(t=>t.visibilityState==="visible"&&!t.url.startsWith("chrome-extension://"))}function ka(e,t){t.isFirebaseMessaging=!0,t.messageType=Z.PUSH_RECEIVED;for(const n of e)n.postMessage(t)}function cn(){return self.clients.matchAll({type:"window",includeUncontrolled:!0})}function Ca(e){var t;const{actions:n}=e,{maxActions:r}=Notification;return n&&r&&n.length>r&&console.warn(`This browser only supports ${r} actions. The remaining actions will not be displayed.`),self.registration.showNotification((t=e.title)!==null&&t!==void 0?t:"",e)}function Oa(e){var t,n,r;const o=(n=(t=e.fcmOptions)===null||t===void 0?void 0:t.link)!==null&&n!==void 0?n:(r=e.notification)===null||r===void 0?void 0:r.click_action;return o||(ba(e.data)?self.location.origin:null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Na(e){if(!e||!e.options)throw we("App Configuration Object");if(!e.name)throw we("App Name");const t=["projectId","apiKey","appId","messagingSenderId"],{options:n}=e;for(const r of t)if(!n[r])throw we(r);return{appName:e.name,projectId:n.projectId,apiKey:n.apiKey,appId:n.appId,senderId:n.messagingSenderId}}function we(e){return T.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let $a=class{constructor(t,n,r){this.deliveryMetricsExportedToBigQueryEnabled=!1,this.onBackgroundMessageHandler=null,this.onMessageHandler=null,this.logEvents=[],this.isLogServiceStarted=!1;const o=Na(t);this.firebaseDependencies={app:t,appConfig:o,installations:n,analyticsProvider:r}}_delete(){return Promise.resolve()}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ba=e=>{const t=new $a(e.getProvider("app").getImmediate(),e.getProvider("installations-internal").getImmediate(),e.getProvider("analytics-internal"));return self.addEventListener("push",n=>{n.waitUntil(Ea(n,t))}),self.addEventListener("pushsubscriptionchange",n=>{n.waitUntil(Ta(n,t))}),self.addEventListener("notificationclick",n=>{n.waitUntil(_a(n))}),t};function Ma(){k(new D("messaging-sw",Ba,"PUBLIC"))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Ma();/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pa="/firebase-messaging-sw.js",Ra="/firebase-cloud-messaging-push-scope",un="BDOU99-h67HcA6JeFXHbSNMu7e2yNNu3RzoMj8TM4W88jITfq7ZmPvIM1Iv-4_l2LxQcYwhqby2xGpWwzjfAnG4",La="https://fcmregistrations.googleapis.com/v1",dn="google.c.a.c_id",Ua="google.c.a.c_l",ja="google.c.a.ts",Fa="google.c.a.e";var mt;(function(e){e[e.DATA_MESSAGE=1]="DATA_MESSAGE",e[e.DISPLAY_NOTIFICATION=3]="DISPLAY_NOTIFICATION"})(mt||(mt={}));/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */var V;(function(e){e.PUSH_RECEIVED="push-received",e.NOTIFICATION_CLICKED="notification-clicked"})(V||(V={}));/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function y(e){const t=new Uint8Array(e);return btoa(String.fromCharCode(...t)).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_")}function xa(e){const t="=".repeat((4-e.length%4)%4),n=(e+t).replace(/\-/g,"+").replace(/_/g,"/"),r=atob(n),o=new Uint8Array(r.length);for(let a=0;a<r.length;++a)o[a]=r.charCodeAt(a);return o}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const me="fcm_token_details_db",Ha=5,yt="fcm_token_object_Store";async function Ka(e){if("databases"in indexedDB&&!(await indexedDB.databases()).map(a=>a.name).includes(me))return null;let t=null;return(await ne(me,Ha,{upgrade:async(r,o,a,s)=>{var i;if(o<2||!r.objectStoreNames.contains(yt))return;const c=s.objectStore(yt),d=await c.index("fcmSenderId").get(e);if(await c.clear(),!!d){if(o===2){const u=d;if(!u.auth||!u.p256dh||!u.endpoint)return;t={token:u.fcmToken,createTime:(i=u.createTime)!==null&&i!==void 0?i:Date.now(),subscriptionOptions:{auth:u.auth,p256dh:u.p256dh,endpoint:u.endpoint,swScope:u.swScope,vapidKey:typeof u.vapidKey=="string"?u.vapidKey:y(u.vapidKey)}}}else if(o===3){const u=d;t={token:u.fcmToken,createTime:u.createTime,subscriptionOptions:{auth:y(u.auth),p256dh:y(u.p256dh),endpoint:u.endpoint,swScope:u.swScope,vapidKey:y(u.vapidKey)}}}else if(o===4){const u=d;t={token:u.fcmToken,createTime:u.createTime,subscriptionOptions:{auth:y(u.auth),p256dh:y(u.p256dh),endpoint:u.endpoint,swScope:u.swScope,vapidKey:y(u.vapidKey)}}}}}})).close(),await j(me),await j("fcm_vapid_details_db"),await j("undefined"),Va(t)?t:null}function Va(e){if(!e||!e.subscriptionOptions)return!1;const{subscriptionOptions:t}=e;return typeof e.createTime=="number"&&e.createTime>0&&typeof e.token=="string"&&e.token.length>0&&typeof t.auth=="string"&&t.auth.length>0&&typeof t.p256dh=="string"&&t.p256dh.length>0&&typeof t.endpoint=="string"&&t.endpoint.length>0&&typeof t.swScope=="string"&&t.swScope.length>0&&typeof t.vapidKey=="string"&&t.vapidKey.length>0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wa="firebase-messaging-database",qa=1,L="firebase-messaging-store";let ye=null;function qe(){return ye||(ye=ne(Wa,qa,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(L)}}})),ye}async function ln(e){const t=Je(e),r=await(await qe()).transaction(L).objectStore(L).get(t);if(r)return r;{const o=await Ka(e.appConfig.senderId);if(o)return await Ge(e,o),o}}async function Ge(e,t){const n=Je(e),o=(await qe()).transaction(L,"readwrite");return await o.objectStore(L).put(t,n),await o.done,t}async function Ga(e){const t=Je(e),r=(await qe()).transaction(L,"readwrite");await r.objectStore(L).delete(t),await r.done}function Je({appConfig:e}){return e.appId}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ja={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"only-available-in-window":"This method is available in a Window context.","only-available-in-sw":"This method is available in a service worker context.","permission-default":"The notification permission was not granted and dismissed instead.","permission-blocked":"The notification permission was not granted and blocked instead.","unsupported-browser":"This browser doesn't support the API's required to use the Firebase SDK.","indexed-db-unsupported":"This browser doesn't support indexedDb.open() (ex. Safari iFrame, Firefox Private Browsing, etc)","failed-service-worker-registration":"We are unable to register the default service worker. {$browserErrorMessage}","token-subscribe-failed":"A problem occurred while subscribing the user to FCM: {$errorInfo}","token-subscribe-no-token":"FCM returned no token when subscribing the user to push.","token-unsubscribe-failed":"A problem occurred while unsubscribing the user from FCM: {$errorInfo}","token-update-failed":"A problem occurred while updating the user from FCM: {$errorInfo}","token-update-no-token":"FCM returned no token when updating the user to push.","use-sw-after-get-token":"The useServiceWorker() method may only be called once and must be called before calling getToken() to ensure your service worker is used.","invalid-sw-registration":"The input to useServiceWorker() must be a ServiceWorkerRegistration.","invalid-bg-handler":"The input to setBackgroundMessageHandler() must be a function.","invalid-vapid-key":"The public VAPID key must be a string.","use-vapid-key-after-get-token":"The usePublicVapidKey() method may only be called once and must be called before calling getToken() to ensure your VAPID key is used."},w=new W("messaging","Messaging",Ja);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ya(e,t){const n=await ze(e),r=pn(t),o={method:"POST",headers:n,body:JSON.stringify(r)};let a;try{a=await(await fetch(Ye(e.appConfig),o)).json()}catch(s){throw w.create("token-subscribe-failed",{errorInfo:s==null?void 0:s.toString()})}if(a.error){const s=a.error.message;throw w.create("token-subscribe-failed",{errorInfo:s})}if(!a.token)throw w.create("token-subscribe-no-token");return a.token}async function za(e,t){const n=await ze(e),r=pn(t.subscriptionOptions),o={method:"PATCH",headers:n,body:JSON.stringify(r)};let a;try{a=await(await fetch(`${Ye(e.appConfig)}/${t.token}`,o)).json()}catch(s){throw w.create("token-update-failed",{errorInfo:s==null?void 0:s.toString()})}if(a.error){const s=a.error.message;throw w.create("token-update-failed",{errorInfo:s})}if(!a.token)throw w.create("token-update-no-token");return a.token}async function fn(e,t){const r={method:"DELETE",headers:await ze(e)};try{const a=await(await fetch(`${Ye(e.appConfig)}/${t}`,r)).json();if(a.error){const s=a.error.message;throw w.create("token-unsubscribe-failed",{errorInfo:s})}}catch(o){throw w.create("token-unsubscribe-failed",{errorInfo:o==null?void 0:o.toString()})}}function Ye({projectId:e}){return`${La}/projects/${e}/registrations`}async function ze({appConfig:e,installations:t}){const n=await t.getToken();return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e.apiKey,"x-goog-firebase-installations-auth":`FIS ${n}`})}function pn({p256dh:e,auth:t,endpoint:n,vapidKey:r}){const o={web:{endpoint:n,auth:t,p256dh:e}};return r!==un&&(o.web.applicationPubKey=r),o}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xa=7*24*60*60*1e3;async function Qa(e){const t=await ts(e.swRegistration,e.vapidKey),n={vapidKey:e.vapidKey,swScope:e.swRegistration.scope,endpoint:t.endpoint,auth:y(t.getKey("auth")),p256dh:y(t.getKey("p256dh"))},r=await ln(e.firebaseDependencies);if(r){if(ns(r.subscriptionOptions,n))return Date.now()>=r.createTime+Xa?es(e,{token:r.token,createTime:Date.now(),subscriptionOptions:n}):r.token;try{await fn(e.firebaseDependencies,r.token)}catch(o){console.warn(o)}return St(e.firebaseDependencies,n)}else return St(e.firebaseDependencies,n)}async function Za(e){const t=await ln(e.firebaseDependencies);t&&(await fn(e.firebaseDependencies,t.token),await Ga(e.firebaseDependencies));const n=await e.swRegistration.pushManager.getSubscription();return n?n.unsubscribe():!0}async function es(e,t){try{const n=await za(e.firebaseDependencies,t),r=Object.assign(Object.assign({},t),{token:n,createTime:Date.now()});return await Ge(e.firebaseDependencies,r),n}catch(n){throw await Za(e),n}}async function St(e,t){const r={token:await Ya(e,t),createTime:Date.now(),subscriptionOptions:t};return await Ge(e,r),r.token}async function ts(e,t){const n=await e.pushManager.getSubscription();return n||e.pushManager.subscribe({userVisibleOnly:!0,applicationServerKey:xa(t)})}function ns(e,t){const n=t.vapidKey===e.vapidKey,r=t.endpoint===e.endpoint,o=t.auth===e.auth,a=t.p256dh===e.p256dh;return n&&r&&o&&a}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Tt(e){const t={from:e.from,collapseKey:e.collapse_key,messageId:e.fcmMessageId};return rs(t,e),os(t,e),as(t,e),t}function rs(e,t){if(!t.notification)return;e.notification={};const n=t.notification.title;n&&(e.notification.title=n);const r=t.notification.body;r&&(e.notification.body=r);const o=t.notification.image;o&&(e.notification.image=o);const a=t.notification.icon;a&&(e.notification.icon=a)}function os(e,t){t.data&&(e.data=t.data)}function as(e,t){var n,r,o,a,s;if(!t.fcmOptions&&!(!((n=t.notification)===null||n===void 0)&&n.click_action))return;e.fcmOptions={};const i=(o=(r=t.fcmOptions)===null||r===void 0?void 0:r.link)!==null&&o!==void 0?o:(a=t.notification)===null||a===void 0?void 0:a.click_action;i&&(e.fcmOptions.link=i);const c=(s=t.fcmOptions)===null||s===void 0?void 0:s.analytics_label;c&&(e.fcmOptions.analyticsLabel=c)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ss(e){return typeof e=="object"&&!!e&&dn in e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */hn("hts/frbslgigp.ogepscmv/ieo/eaylg","tp:/ieaeogn-agolai.o/1frlglgc/o");hn("AzSCbw63g1R0nCw85jG8","Iaya3yLKwmgvh7cF0q4");function hn(e,t){const n=[];for(let r=0;r<e.length;r++)n.push(e.charAt(r)),r<t.length&&n.push(t.charAt(r));return n.join("")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function is(e){if(!e||!e.options)throw Se("App Configuration Object");if(!e.name)throw Se("App Name");const t=["projectId","apiKey","appId","messagingSenderId"],{options:n}=e;for(const r of t)if(!n[r])throw Se(r);return{appName:e.name,projectId:n.projectId,apiKey:n.apiKey,appId:n.appId,senderId:n.messagingSenderId}}function Se(e){return w.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cs{constructor(t,n,r){this.deliveryMetricsExportedToBigQueryEnabled=!1,this.onBackgroundMessageHandler=null,this.onMessageHandler=null,this.logEvents=[],this.isLogServiceStarted=!1;const o=is(t);this.firebaseDependencies={app:t,appConfig:o,installations:n,analyticsProvider:r}}_delete(){return Promise.resolve()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function us(e){try{e.swRegistration=await navigator.serviceWorker.register(Pa,{scope:Ra}),e.swRegistration.update().catch(()=>{})}catch(t){throw w.create("failed-service-worker-registration",{browserErrorMessage:t==null?void 0:t.message})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ds(e,t){if(!t&&!e.swRegistration&&await us(e),!(!t&&e.swRegistration)){if(!(t instanceof ServiceWorkerRegistration))throw w.create("invalid-sw-registration");e.swRegistration=t}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ls(e,t){t?e.vapidKey=t:e.vapidKey||(e.vapidKey=un)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function gn(e,t){if(!navigator)throw w.create("only-available-in-window");if(Notification.permission==="default"&&await Notification.requestPermission(),Notification.permission!=="granted")throw w.create("permission-blocked");return await ls(e,t==null?void 0:t.vapidKey),await ds(e,t==null?void 0:t.serviceWorkerRegistration),Qa(e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function fs(e,t,n){const r=ps(t);(await e.firebaseDependencies.analyticsProvider.get()).logEvent(r,{message_id:n[dn],message_name:n[Ua],message_time:n[ja],message_device_time:Math.floor(Date.now()/1e3)})}function ps(e){switch(e){case V.NOTIFICATION_CLICKED:return"notification_open";case V.PUSH_RECEIVED:return"notification_foreground";default:throw new Error}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function hs(e,t){const n=t.data;if(!n.isFirebaseMessaging)return;e.onMessageHandler&&n.messageType===V.PUSH_RECEIVED&&(typeof e.onMessageHandler=="function"?e.onMessageHandler(Tt(n)):e.onMessageHandler.next(Tt(n)));const r=n.data;ss(r)&&r[Fa]==="1"&&await fs(e,n.messageType,r)}const Et="@firebase/messaging",_t="0.12.4";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gs=e=>{const t=new cs(e.getProvider("app").getImmediate(),e.getProvider("installations-internal").getImmediate(),e.getProvider("analytics-internal"));return navigator.serviceWorker.addEventListener("message",n=>hs(t,n)),t},bs=e=>{const t=e.getProvider("messaging").getImmediate();return{getToken:r=>gn(t,r)}};function ws(){k(new D("messaging",gs,"PUBLIC")),k(new D("messaging-internal",bs,"PRIVATE")),A(Et,_t),A(Et,_t,"esm2017")}async function ms(e,t){return e=Rn(e),gn(e,t)}ws();const ys="/assets/index.js-loader-bafe20f3.js",_=vt();async function Ss(){const e=await Us(),t=new Date().toDateString();if(!(e===null||new Date(e.requestDate).toDateString()!==t))return e.available;const r=await g(`${h}/cities`);if(!r.ok)return e===null?[]:e.available;const o=await r.json(),a={requestDate:t,available:o.available.map(s=>({id:s.id,name:s.name}))};return await C(Te,a),a.available}async function Ts(e){const t=await mn(),n=new URLSearchParams({cityId:`${t.id}`,url:e}),r=await g(`${h}/v1/products/scan?${n.toString()}`);if(!r.ok){const o=new Error("failed to retrieve data from the server");throw o.response=r,o}return await r.json()}async function Es(){try{const e=await g(`${h}/init`);if(!e.ok)return Qe;const t=await e.json();return wn(t.city)}catch{return Qe}}async function _s(e){const{authToken:t}=await E();if(!t)return{success:!1};const n={method:"POST",body:JSON.stringify(e)};return{success:(await g(`${h}/v1/products/subscriptions`,n)).ok}}async function Is(e){const{authToken:t}=await E();if(!t)return{success:!1};const n={method:"DELETE",body:JSON.stringify(e)};return{success:(await g(`${h}/v1/products/subscriptions`,n)).ok}}async function As(e){const{authToken:t}=await E();if(!t)return await C(U,e),{success:!0};const n={method:"PUT",body:JSON.stringify({city_id:e.id})},r=await g(`${h}/user/city`,n);return r.ok?(await C(U,e),await r.json()):{success:!1}}async function vs(e){const t={method:"POST",body:JSON.stringify(e)};await g(`${h}/v1/logs`,t)}async function Ds(e){const t={method:"POST",body:JSON.stringify(e)};await g(`${h}/v1/events`,t)}async function ks(e){e.currentPageUrl=l.identity.getRedirectURL();const t={method:"POST",body:JSON.stringify(e)};return{success:(await g(`${h}/feedback`,t)).ok}}async function Cs(){const{authToken:e}=await E();if(!e)return null;const t=await g(`${h}/init`),{user:n}=await t.json(),r=bn(n);return await C(H,r),r.authUser}function Os(){const e="https://accounts.google.com/o/oauth2/auth",t=l.identity.getRedirectURL().slice(0,-1),n={client_id:_n,redirect_uri:t,response_type:"code",scope:["email","profile"].join(" ")};_.info("Google auth params",{clientId:n.client_id,redirectUrl:n.redirect_uri,scope:n.scope});async function r(o){const a=new URL(o).searchParams.get("code"),s=`${h}/v1/auth/google`,i=await g(s,{method:"POST",body:JSON.stringify({code:a,clientType:"extension",redirectUrl:t})});if(!i.ok)throw new Error("Authentication failed");const c=await i.json();return Xe(c)}return l.identity.launchWebAuthFlow({url:`${e}?${new URLSearchParams(n).toString()}`,interactive:!0}).then(r).catch(o=>({success:!1}))}async function Ns(e){const t={method:"POST",body:JSON.stringify(e)},r=await(await g(`${h}/auth/user/create`,t)).json();return r.errors?{success:!1,errorMessages:r.errors}:Xe(r)}async function $s(e){const t={method:"POST",body:JSON.stringify(e)},n=await g(`${h}/v1/auth/send-login-link`,t);return n.ok?{success:!0}:{success:!1,errorMessages:(await n.json()).errors}}async function Bs(e){const t={method:"POST",body:JSON.stringify(e)},r=await(await g(`${h}/v1/auth/confirm`,t)).json();return r.errors||r.message==="Invalid code"?{success:!1,errorMessages:r.errors??{code:["validation.invalid"]}}:Xe(r)}function Xe(e){const{user:t,city:n}=e,r=bn(t),o=wn(n);return{success:!0,userData:{authUserData:r,city:o}}}async function Ms(e){const{authUserData:t,city:n}=e;return await Promise.all([C(H,t),C(U,n)]),{authUser:t.authUser,city:n}}async function Ps(){try{const t=await g(`${h}/v1/auth/logout`,{method:"POST"});_.info("logout response",t.status)}catch(t){_.error("logout request failed"),_.captureException(t)}const e="https://accounts.google.com/o/oauth2/revoke?token=";try{const{token:t}=await l.identity.getAuthToken(),n=await fetch(e+t);_.info("google auth token was revoke",n.status)}catch{_.error("google auth token was empty")}await Promise.all([l.storage.local.remove(H),l.storage.local.remove(z)])}async function Rs(){const{userData:{authUser:e},city:t}=await Ls();return{authUser:e,city:t}}function bn(e){if(e===null)return At;const t=e.subscriptions;return _.info("User info",{user:e,subscriptions:t}),{authToken:`${e.uuid}:${e.token}`,authUser:{email:e.email,id:e.id,isEmailConfirmed:e.isEmailConfirmed,telegramId:e.telegramId,telegramName:e.telegramName,telegramConnectUrl:e.telegramConnectUrl,subscriptions:{rozetkaProductCount:t.rozetkaProduct.length,alcoholProductCount:t.alcohol.length}}}}function wn(e){return{id:e.id,name:e.name}}async function Ls(){const[e,t]=await Promise.all([E(),mn()]);return{userData:e,city:t}}async function E(){const{[H]:e}=await l.storage.local.get(H);return e?JSON.parse(e):At}async function mn(){const{[U]:e}=await l.storage.local.get(U);if(!e){const t=await Es();return await C(U,t),t}return JSON.parse(e)}async function Us(){const{[Te]:e}=await l.storage.local.get(Te);return e?JSON.parse(e):null}async function js(){const{[z]:e}=await await l.storage.local.get(z);return e?JSON.parse(e):""}async function C(e,t){await l.storage.local.set({[e]:JSON.stringify(t)})}async function Fs(e){const{authToken:t}=await E();if(!t)return;const n=await js();if(_.info("Push token",{oldToken:n,newToken:e,changed:n!==e}),e===n)return;const r={method:"POST",body:JSON.stringify({token:e,client:"extension"})},o=await g(`${h}/v1/user/push-token`,r);return o.ok&&await C(z,e),{success:o.ok}}async function g(e,t=null){const n=t??{method:"GET"};n.credentials="omit";const r=new Headers(n.headers??{}),{authToken:o}=await E();return o&&r.append("Authorization",o),r.append("X-App-Agent",Js()),r.append("Content-Type","application/json"),n.headers=r,await fetch(e,n)}function xs(e){const t=new Map;return{getResponseObjFromCache:n=>t.get(n),removeResponseObjFromCache:n=>t.delete(n),createNewResponseObj:(n,r,o={})=>{const a={requestUrl:r,error:!1,promiseObj:s(),reason:null};async function s(){var i;try{return await e(r,o)}catch(c){return((i=c.response)==null?void 0:i.status)===404&&(t.set(n,a),a.reason=404),a.error=!0,{error:"Bad response status code"}}}return t.set(n,a),a}}}const b=vt();b.info("background is running");l.runtime.onInstalled.addListener(async()=>{b.info("Background script was installed or updated");const e="main-content-script",t=await l.scripting.getRegisteredContentScripts({ids:[e]});if(b.info("REGISTER SCRIPTS",t),t.length){b.info("Scripts are already registered");return}b.info("Registering scripts...");const n=[];for(const o of N.iterShopHostRules())n.push(`https://${o}/*`);const r=[{matches:n,js:[ys],id:e,runAt:"document_end"}];try{await l.scripting.registerContentScripts(r)}catch(o){b.error("Failed to register scripts"),b.captureException(o)}});l.action.onClicked.addListener(async e=>{const t={type:$.OPEN_EXTENSION_DATA};await G(e.id,t)});const Ne=xs(Ts),q=e=>{Ne.removeResponseObjFromCache(e)},yn=(e,t)=>{const n=new URL(t);n.hash="";const r=n.href;let o=Ne.getResponseObjFromCache(e);return((o==null?void 0:o.requestUrl)!==r||o.error&&o.reason!==404)&&(o=Ne.createNewResponseObj(e,r)),o},It=async(e,t,n=!1)=>{const r=l.runtime.getURL(n?"img/logo-128.png":"img/logo-128-disabled.png");if(await l.action.setIcon({tabId:e,path:r}),!t){await l.action.setBadgeText({tabId:e,text:""});return}const o=t>0?Ze.ABOVE_MINIMUM_PRICE:Ze.BEST_PRICE;await l.action.setBadgeText({tabId:e,text:`${t}%`}),await l.action.setBadgeBackgroundColor({tabId:e,color:o})};l.tabs.onUpdated.addListener(async(e,t,n)=>{if(t.status!=="loading")return;const r=t.url??n.url;if(!N.isSupportedUrl(r)){q(e);try{await It(e,0,N.isSupportedHost(r))}catch{}return}const a=await yn(e,r).promiseObj,s=N.findShopIdByUrl(r),i=In(a.shops??[],s);try{await It(e,i,!0)}catch{}});l.tabs.onRemoved.addListener(q);l.runtime.onMessage.addListener((e,t,n)=>{switch(b.info("onMessage",e),e.type){case p.FETCH_PRODUCT_DETAILS:const r=t.tab.id,o=e.url;yn(r,o).promiseObj.then(i=>n(i));break;case p.SIGN_IN_USE_GOOGLE:Os().then(i=>n(i));break;case p.SIGN_UP_USE_BADSELLER_ACCOUNT:Ns(e.requestBody).then(i=>n(i));break;case p.LOGIN:Ms(e.userData).then(i=>n(i));break;case p.SIGN_OUT_OF_ACCOUNT:Ps().then(i=>n(i));break;case p.VERIFY_THE_ACCOUNT_EXISTS:$s(e.requestBody).then(i=>n(i));break;case p.GET_USER_DATA:Rs().then(i=>n(i));break;case p.CONFIRM_EMAIL_FOR_BADSELLER_ACCOUNT:Bs(e.requestBody).then(i=>n(i));break;case p.OPEN_PRODUCT_LINK_IN_NEW_TAB:Hs(e.url).then(i=>n(i));break;case p.OPEN_LINK_WITH_AUTO_LOGIN:Ks(e.url,e.utmTags).then(()=>n());break;case p.GET_AUTO_LOGIN_LINK:Sn(e.url,e.utmTags).then(i=>n(i));break;case p.SUBSCRIBE_TO_PRICE_CHANGE:_s(e.requestBody).then(i=>n(i));break;case p.UNSUBSCRIBE_FROM_PRICE_CHANGE:Is(e.requestBody).then(i=>n(i));break;case p.GET_CITIES_LIST:Ss().then(i=>n(i));break;case p.UPDATE_USER_CITY:As(e.city).then(i=>n(i));break;case p.UPDATE_PRODUCT_DETAILS_ON_SELECTED_TAB:const s={type:$.UPDATE_PRODUCT_ON_CURRENT_TAB};q(t.tab.id),G(t.tab.id,s).then(i=>{n(i)});break;case p.SET_USER_DATA_ON_EACH_TAB:Ws(t.tab.id).then(i=>{n(i)});break;case p.SUBSCRIPTION_WAS_CHANGED:Vs(t.tab.id,e.productId).then(()=>{n()});break;case p.SEND_ANALYTICAL_DATA:Ds(e.requestBody).then(()=>n());break;case p.SEND_FEEDBACK:ks(e.requestBody).then(i=>n(i));break;case p.SUBSCRIBE_TO_WEB_PUSH_NOTIFICATIONS:Gs().then(i=>n(i));break;case p.SET_LATEST_USER_DATA:Cs().then(i=>n(i));break;case p.SEND_ERROR_MESSAGE:vs(e.requestBody).then(()=>n());break}return!0});l.windows.onFocusChanged.addListener(async e=>{if(!e||e===-1||(await l.windows.get(e)).type!=="normal")return;const[n]=await l.tabs.query({windowId:e,active:!0}),r=n.url;if(r&&N.isSupportedUrl(r)){const o={type:$.TAB_WAS_ACTIVATED};await G(n.id,o)}});l.tabs.onActivated.addListener(async e=>{const n=(await l.tabs.get(e.tabId)).url;if(n&&N.isSupportedUrl(n)){const r={type:$.TAB_WAS_ACTIVATED};await G(e.tabId,r)}});async function Hs(e){const t={active:!0,lastFocusedWindow:!0},[n]=await l.tabs.query(t);await l.tabs.create({active:!0,index:n.index+1,url:e})}async function Sn(e,t){const n=new URL(`${An}/${e}`),r=new URLSearchParams(Object.entries(t)),{authToken:o}=await E();if(o){const[a,s]=o.split(":");r.append("u",a),r.append("t",s)}for(const[a,s]of r.entries())n.searchParams.append(a,s);return n.toString()}async function Ks(e,t){const n={active:!0,lastFocusedWindow:!0},r=await Sn(e,t),[o]=await l.tabs.query(n);await l.tabs.create({active:!0,index:o.index+1,url:r})}async function Vs(e,t){async function n(o){const a={type:$.GET_PRODUCT_ID},s=await l.tabs.sendMessage(o,a);t===s&&(q(o),await l.tabs.sendMessage(o,{type:$.SET_LAZY_LOAD}))}const r=await Tn(e);await Promise.allSettled([r.map(o=>n(o.id))])}async function Ws(e){const t={type:$.SET_USER_DATA_FROM_SESSION},n=await Tn(e);await Promise.allSettled(n.map(r=>(q(r.id),G(r.id,t))))}async function Tn(e){return(await l.tabs.query({})).filter(n=>{const r=n.url;return n.id!==e&&r&&N.isSupportedHost(r)})}async function G(e,t){try{await l.tabs.sendMessage(e,t)}catch(n){b.error(`failed to send a message => "${t.type}" to the tab with the identifier ${e}`),b.captureException(n)}}let qs=null;async function Gs(){const{authToken:e}=await E();if(!e){b.warn("User NOT logged in, PUSH TOKEN WAS NOT UPDATED");return}b.success("Update user web push token");const t=await ms(qs,{vapidKey:vn,serviceWorkerRegistration:self.registration});await Fs(t)}b.warn("Push notifications disabled");function Js(){const e=self.location.protocol,t=l.runtime.getManifest().version;return`${e}${t}`}export{Js as getClient};
